# Rà mẫu Exp A: vì sao F1 embedding còn thấp

Ngày 2026-10-14 · 29 bài · Codex rà theo title/abstract · **Nhận định tạm thời, chưa được người xác nhận.**

Điểm **38.06% micro F1** của lượt 400 bài đang gộp ít nhất ba nguồn sai khác: Qwen trích nhãn chưa đúng/đủ, reference có mục thiếu hoặc chưa thống nhất, và matcher dùng cosine chưa nhận biết tương đương ngữ nghĩa đáng tin cậy. Không thể đọc điểm này thành “Qwen chỉ hiểu đúng 38.06%”.

Trong mẫu ngẫu nhiên 20 bài, đã ghi nhận cờ cần xử lý ở Qwen trên **20/20 bài**, ở reference trên **15/20**, và ở matcher trên **15/20**. Một bài có cờ không có nghĩa mọi nhãn của bài đều sai; các nhóm nguyên nhân chồng lấp. Đây là phát hiện chẩn đoán trên mẫu, không phải tỷ trọng các lỗi của 400 bài.

## Cách lấy mẫu và giới hạn

- Lấy 20 ID ngẫu nhiên bằng seed `20261014` từ 391 bài còn lại sau khi loại 4 ví dụ đã bàn và 5 bài đang pending nguồn; thuật toán và ID lưu trong `summary.json`.
- Rà thêm riêng 4 ví dụ đã thấy trước và toàn bộ 5 bài nguồn có vấn đề; giữ tách nhóm khi thống kê.
- Với 20 bài ngẫu nhiên, ghi chú từ nguồn được lưu trước khi mở bảng nhãn trong lượt rà này. Đây vẫn là cùng cuộc hội thoại, không phải lượt AI độc lập hay blind review. Ghi chú năm facet là bản tóm tắt, không phải reference mới đầy đủ.
- Đối chiếu cả nhãn dư/thiếu lẫn các cặp đã được evaluator ghép. Có rà cả năm facet của từng bài; sổ audit chỉ ghi các điểm có ích để chẩn đoán, chưa adjudicate mọi nhãn/cặp.
- Dùng [quy trình semantic review](SEMANTIC_REVIEW_PROTOCOL.md): task là mục tiêu tác nghiệp; dataset là named resource; contribution gồm artifact/finding mới; giữ điều kiện, comparator và số liệu. Corpus được gọi tên có thể thuộc dataset, nhưng mô tả “two datasets” chưa đạt chính sách này.
- Reference hiện tại là AI reference. Không sửa reference, silver, evaluator, ngưỡng hoặc output 400 bài trong lượt audit. Chưa tính semantic precision/recall/F1 đã sửa.

## Số bài có ít nhất một cờ

| Nhóm | Số bài | Qwen | Reference | Matcher | Cần chốt nguồn/quy tắc |
|---|---:|---:|---:|---:|---:|
| Ngẫu nhiên | 20 | 20 | 15 | 15 | 6 |
| Ví dụ đã bàn | 4 | 4 | 1 | 2 | 0 |
| Pending nguồn | 5 | 5 | 2 | 3 | 5 |

Đếm theo bài, các cột chồng lấp và không được cộng thành tổng. Có 121 ghi nhận chọn lọc: 59 về Qwen, 22 về reference, 29 về matcher và 11 chưa chốt. Số lượng ghi nhận phụ thuộc cách gộp vấn đề; không dùng chúng để tính phần trăm nguyên nhân lỗi.

## Những ví dụ quyết định

### 1. Matcher bỏ ghép cùng một dataset

`P001906`: Qwen ghi `Natural Questions benchmark dataset`, reference ghi `Natural Questions`. Cả hai chỉ cùng benchmark được nguồn nêu, nhưng cosine **0.8277 < 0.85** nên không ghép. `P001758`: `atis corpus` và `ATIS` cũng bị bỏ ghép, cosine **0.6341**.

Điều này cho thấy cosine của nhãn ngắn và dài có thể thấp dù cùng tên/tài nguyên. Canonical name ngắn và evidence riêng sẽ hữu ích hơn việc embed cả câu mô tả như tên resource.

### 2. Matcher ghép sai dù điểm cao

`P001880`: evaluator ghép `Encoder Network achieved a correlation of ~0.84` với `correlation of the Encoder Network was improved by ~13%`, cosine **0.8909**. Nguồn nói cả hai điều, nhưng một bên là mức correlation, một bên là mức cải thiện. Hai phát biểu không tương đương.

> For the post challenge, the performance of both Random Forest and the Encoder Network was improved; in particular, the correlation of the Encoder Network was improved by ~13%.

> In contrast, with the sentence embeddings pre-trained on biomedical corpora, the Encoder Network now achieves a correlation of ~0.84, which is higher than the original best model.

`P002925`: evaluator ghép `perform a rigorous measurement study characterizing the linguistic structure of counterspeech` với `detect different types of counterspeech`, cosine **0.8525**. Phân tích cấu trúc ngôn ngữ và phân loại loại counterspeech là hai thao tác khác nhau. Trong cùng facet, Qwen có nhãn tự động detect counterspeech đúng thao tác nhưng chỉ đạt **0.8487**, bị bỏ ghép.

Hạ ngưỡng có thể cứu một số cặp tương đương và nhận thêm cặp khác nghĩa. Chỉ riêng cặp sai 0.8909 đã cao hơn cặp cùng dataset 0.8277: một cutoff cosine đơn lẻ không thể nhận đúng cặp sau đồng thời loại đúng cặp trước.

### 3. Reference thiếu finding có nguồn

`P000949`: reference contribution chỉ có `Sentinel`, trong khi Qwen và abstract còn nêu kết quả vượt các personalized filters trước đó:

> Comparisons show that the performance of Sentinel surpasses that of a number of state-of-the-art personalized filters proposed in previous studies.

`P001099`: source/Qwen nêu seq2seq simulator vượt agenda-based và n-gram simulator theo F-score, nhưng reference bỏ finding này. `P001274`, thuộc nhóm ví dụ đã bàn, có hai findings tương tự bị thiếu. Những nhãn có nguồn vẫn bị tính dư khi không có đối tác reference.

### 4. Reference ghi lặp cùng một concept

`P003998` có hai contribution labels `sentimentspecific word embedding` và `SSWE`, nhưng nguồn đặt acronym trực tiếp:

> We address this issue by learning sentimentspecific word embedding (SSWE), which encodes sentiment information in the continuous representation of words.

`P003096` cũng ghi cả `story ending prediction` và `story ending selection` cho cùng thao tác trong bài. Ghép một–một là quy tắc hợp lý, nhưng cần xử lý alias trùng ở reference trước; không cho một Qwen label ghép hai lần để bù nhãn trùng.

### 5. Qwen có lỗi trích xuất thực sự

- `P002814`: problem chọn câu giới thiệu sự phổ biến của author profiling, bỏ spelling/grammar/transliteration và thiếu dữ liệu code-mixed.
- `P002421`: task chọn graph convolution thay vì digit classification trong thí nghiệm MNIST.
- `P003063`: task chọn cơ chế expose layer signals thay vì neural machine translation.
- `P002575`, `P003677`, `P003998`: contribution chỉ giữ hiệu năng, bỏ artifact mới; ở một số bài khác lại chỉ giữ artifact và bỏ finding.
- Nhiều nhãn dataset như “very large text corpora”, “two independent datasets” chưa có tên theo quy tắc dataset hiện hành. Chúng có thể được nguồn hỗ trợ như mô tả dữ liệu, nhưng chưa hợp lệ cho facet này.

## Hướng xử lý đề xuất

1. **Chốt quy tắc và chỉnh reference trên nguồn trước.** Gộp alias trùng, giữ điều kiện findings, bổ sung task/artifact/finding chính bị thiếu. Quyết định rõ method có bao gồm baseline thực sự chạy hay không và mức độ tách concept. Các nhãn thuộc tính như số mẫu không tự trở thành artifact riêng.
2. **Chuẩn hóa cách trích nhãn Qwen.** Tên task/method/resource/artifact dùng concept ngắn có danh tính rõ và evidence riêng; finding giữ mệnh đề đủ comparator/qualifier. Tách từng resource và concept theo cùng quy tắc với reference. Không cắt ngắn finding chỉ để tăng cosine.
3. **Hiệu chỉnh matcher bằng cặp nguồn thật đã được xác nhận.** Đưa cả alias, câu ngắn/dài và hard negatives về metric, tác vụ, phủ định/điều kiện vào tập hiệu chỉnh; giữ tập kiểm tra riêng chưa dùng chọn ngưỡng. Các cặp được chọn ở audit này dùng để chẩn đoán, không phải tập test độc lập.
4. **Giữ điểm hiện tại dưới tên agreement với AI reference.** Sau khi reference và cặp đối chiếu được người xác nhận, mới chạy lại và báo semantic F1. Chưa có cơ sở chọn một ngưỡng mới từ 29 bài này.

Không cần thêm LLM judge vào pipeline để thực hiện các bước chuẩn hóa và embedding; việc chốt chất lượng reference và tập cặp vẫn cần review đáng tin cậy. Audit hiện tại do Codex nhận định, có thể cần chỉnh sau khi người đọc xác nhận.

## Sổ từng bài

Mỗi dòng dưới đây tương ứng một ghi nhận có nhãn gốc, trích nguồn, độ tin cậy và cosine (khi có) trong `audit.jsonl`. Các mục chưa chốt chỉ đánh dấu việc cần xác minh, không quy thành lỗi chắc chắn.

### 20 bài ngẫu nhiên

**P000938 — Stochastic Language Generation in Dialogue using Factored Language Models**

- `P000938-01` · Qwen / problem: Qwen bỏ sót hạn chế thiếu utterance theo miền, dù abstract nêu trực tiếp.
- `P000938-02` · Qwen / contribution: Hai nhãn đóng góp diễn đạt lại cùng kết quả cải thiện độ tự nhiên bằng biến thiên utterance; cần gộp một ý.
- `P000938-03` · Qwen / dataset: Số utterance và annotator là mô tả dữ liệu, không phải tên tài nguyên theo guideline hiện tại.
- `P000938-04` · Ghép embedding / method: Cùng structured perceptron được mô tả dài và ngắn trong cùng bài; cosine thấp hơn 0.85. Cosine 0.8414; không ghép.

**P000949 — Personalized Spam Filtering with Natural Language Attributes**

- `P000949-01` · Qwen / method: Nhãn meta-learning chung bỏ mất tên AdaBoostM1 và Bagging thực sự được thử nghiệm.
- `P000949-02` · Qwen / task: Nhãn task nói hành động báo cáo hiệu năng thay vì nhiệm vụ phân loại spam cá nhân hóa.
- `P000949-03` · Tham chiếu / contribution: Kết quả Sentinel vượt các bộ lọc cá nhân hóa trước đó có trong nguồn và Qwen, nhưng reference chỉ giữ tên hệ thống.
- `P000949-04` · Chưa chốt / method: Nguồn đánh giá cả SVM và Naive Bayes nhưng reference bỏ hai tên này. Cần thống nhất có tính các baseline thực sự chạy vào method hay không.

**P001099 — A Sequence-to-Sequence Model for User Simulation in Spoken Dialogue Systems**

- `P001099-01` · Qwen / contribution: Qwen giữ các kết quả nhưng bỏ artifact mới là user simulator khỏi contribution.
- `P001099-02` · Tham chiếu / problem: Reference bỏ hai hạn chế có nguồn rõ ràng: cần cấu trúc cứng và phải tóm tắt action space.
- `P001099-03` · Tham chiếu / contribution: Kết quả vượt agenda-based và n-gram simulator theo F-score không có nhãn tương ứng trong reference.
- `P001099-04` · Ghép embedding / method: Mô tả dài vẫn xác định đúng encoder-decoder RNN được dùng; nhãn ngắn cùng phương pháp bị bỏ ghép. Cosine 0.7514; không ghép.
- `P001099-05` · Ghép embedding / contribution: Hai nhãn cùng kết quả mô hình hóa user behaviour với độ hạt mịn hơn; câu dài thêm cách đạt được kết quả. Cosine 0.7696; không ghép.

**P001715 — Social topic models for community extraction**

- `P001715-01` · Qwen / contribution: Qwen bỏ kết quả trích được cộng đồng vừa kết nối tốt vừa có ý nghĩa chủ đề khỏi contribution.
- `P001715-02` · Tham chiếu / contribution: Kết quả chủ đề ánh xạ về sự kiện Enron trong đời thực có nguồn nhưng bị thiếu ở reference.
- `P001715-03` · Ghép embedding / task: Extract latent communities và community extraction là cùng mục tiêu thao tác trong nguồn. Cosine 0.7198; không ghép.
- `P001715-04` · Ghép embedding / contribution: Hai nhãn chỉ cùng Bayesian generative model được đề xuất; nhãn dài thêm đặc điểm tích hợp link và content. Cosine 0.7293; không ghép.

**P001851 — Controversy in Context**

- `P001851-01` · Qwen / contribution: Qwen giữ artifact dataset nhưng bỏ phát hiện về khả năng chỉ báo controversiality của textual context.
- `P001851-02` · Qwen / dataset: Dataset mới chỉ được mô tả, chưa có tên; không đạt chính sách named resource cho facet dataset.
- `P001851-03` · Ghép embedding / task: Nhãn dài vẫn nêu controversiality prediction; mệnh đề hiệu năng đi kèm không đổi nhiệm vụ chính. Cosine 0.7944; không ghép.

**P001880 — Deep learning with sentence embeddings pre-trained on biomedical corpora improves the performance of finding similar sentences in electronic medical records**

- `P001880-01` · Qwen / method: Qwen chỉ ghi họ thuật toán chung và embeddings, bỏ tên Random Forest, Encoder Network và ensemble tám mô hình.
- `P001880-02` · Qwen / dataset: Qwen ghi số cặp câu nhưng bỏ các tài nguyên được gọi tên: BioCreative/OHNLP STS, PubMed và MIMIC-III.
- `P001880-03` · Tham chiếu / contribution: Reference chỉ giữ cải thiện khoảng 13%, bỏ kết quả ensemble tám mô hình đạt mức tốt nhất ở challenge.
- `P001880-04` · Ghép embedding / contribution: Một giá trị correlation khoảng 0.84 và mức cải thiện khoảng 13% là hai đại lượng khác nhau. Evaluator đã ghép cặp này thành đúng. Cosine 0.8909; đã ghép.

**P001906 — Frustratingly Easy Natural Question Answering**

- `P001906-01` · Qwen / task: Qwen ghi hoạt động evaluate trên benchmark mà không giữ nhiệm vụ Question Answering.
- `P001906-02` · Tham chiếu / contribution: Nhãn 1.9 F1 points đứng riêng làm mất đối tượng so sánh và điều kiện ít hơn bốn triệu ví dụ; cần giữ thành mệnh đề kết quả.
- `P001906-03` · Ghép embedding / dataset: Natural Questions benchmark dataset và Natural Questions chỉ cùng benchmark. Cosine 0.8277; không ghép.
- `P001906-04` · Ghép embedding / problem: Hai nhãn cùng hạn chế thiếu research documentation; nhãn dài giữ thêm chủ thể QA leaderboard. Cosine 0.7024; không ghép.

**P002079 — Large Scale Sentiment Learning with Limited Labels**

- `P002079-01` · Qwen / task: Qwen chỉ ghi sentiment analysis, bỏ thao tác annotation Twitter dataset là công việc chính được mô tả.
- `P002079-02` · Ghép embedding / dataset: Nguồn xác định dataset Twitter 2015 được cung cấp chính là TSentiment15. Hai nhãn đồng chỉ trong bài, nhưng tên chuẩn bị thiếu ở Qwen. Cosine 0.7011; không ghép.
- `P002079-03` · Chưa chốt / problem: Qwen thêm tình trạng thiếu dataset nói chung có trong nguồn; reference chỉ giữ hạn chế stream của TSentiment cũ. Cần quy tắc chọn mức độ bao phủ problem.

**P002086 — Visual Exploration of Semantic Relationships in Neural Word Embeddings**

- `P002086-01` · Qwen / task: Các nhãn task chủ yếu nhắc mục tiêu chung hoặc cách trực quan hóa có trước; chưa giữ mục tiêu mới là trực quan semantic và syntactic analogies.
- `P002086-02` · Qwen / problem: Qwen giữ bối cảnh ít hiểu không gian embedding nhưng bỏ hạn chế trực tiếp: các kỹ thuật cho kết quả mediocre hoặc misleading.
- `P002086-03` · Tham chiếu / contribution: Nguồn và Qwen nêu các embedding techniques mới; reference chỉ giữ hai views và t-SNE có uncertainty.
- `P002086-04` · Chưa chốt / method: PCA được nêu khi mô tả thực hành có trước, không rõ trong abstract có được triển khai trong phương pháp mới hay chỉ làm bối cảnh.

**P002401 — Unsupervised Learning of Word-Category Guessing Rules**

- `P002401-01` · Qwen / method: Qwen gộp thành ba bộ quy tắc nhưng không giữ tên prefix, suffix và ending-guessing được nguồn chỉ rõ.
- `P002401-02` · Qwen / contribution: Qwen chỉ giữ nhận định hiệu năng chung, bỏ artifact kỹ thuật học quy tắc và ba bộ quy tắc mới.
- `P002401-03` · Tham chiếu / contribution: Kết quả rule-set có hiệu năng cạnh tranh có trong nguồn và Qwen nhưng chưa có trong reference.
- `P002401-04` · Chưa chốt / task: Reference ghi cả POS tagging và đoán POS cho từ chưa biết; chúng là mục tiêu rộng và hẹp, cần quy tắc một ý hay hai ý.

**P002421 — Graph Based Convolutional Neural Network**

- `P002421-01` · Qwen / task: Qwen ghi graph convolution/deep learning trên miền bất quy tắc; task ứng dụng được nguồn đánh giá là phân loại chữ số MNIST.
- `P002421-02` · Qwen / contribution: Nhãn nói evaluation được trình bày nhưng chưa giữ kết quả 94.23% và 94.96%; đây chưa phải mệnh đề finding.
- `P002421-03` · Ghép embedding / contribution: Nhãn dài và ngắn cùng chỉ graph convolution and pooling operators mới. Cosine 0.8182; không ghép.
- `P002421-04` · Tham chiếu / problem: Irregular spatial domain đứng riêng là miền dữ liệu, chưa diễn đạt được trở ngại thiết kế/convolution kernel mà nguồn nêu.

**P002441 — Visually Grounded and Textual Semantic Models Differentially Decode Brain Activity Associated with Concrete and Abstract Nouns**

- `P002441-01` · Qwen / dataset: Qwen ghi tập danh từ chung, bỏ hai nguồn có tên Wikipedia và Google Images.
- `P002441-02` · Qwen / contribution: Qwen bỏ kết quả text-based models tốt hơn cho các danh từ trừu tượng nhất.
- `P002441-03` · Tham chiếu / contribution: Reference bỏ điều kiện for the most abstract nouns, khiến phát hiện có thể bị hiểu là text-based luôn tốt hơn.
- `P002441-04` · Ghép embedding / method: Mô tả dài vẫn nêu đúng word2vec skipgram được dùng; không nên xem khác phương pháp chỉ vì thêm Wikipedia. Cosine 0.8212; không ghép.

**P002575 — Improving Word Representations via Global Context and Multiple Word Prototypes**

- `P002575-01` · Qwen / contribution: Qwen chỉ ghi hiệu năng, bỏ hai artifact được giới thiệu: kiến trúc mạng và dataset với human judgments.
- `P002575-02` · Qwen / method: Tên kiến trúc chung không giữ hai thiết kế chủ chốt: local/global context và nhiều embedding cho một từ.
- `P002575-03` · Qwen / dataset: Dataset với human judgments được mô tả nhưng chưa có tên theo chính sách named resource.
- `P002575-04` · Tham chiếu / contribution: Kết quả vượt competitive baselines và neural language models có nguồn và Qwen, nhưng thiếu ở reference.
- `P002575-05` · Ghép embedding / problem: Nhãn dài và ngắn cùng hạn chế chỉ dùng local context và một representation mỗi từ. Cosine 0.8377; không ghép.

**P002739 — Joint Person Segmentation and Identification in Synchronized First- and Third-person Videos**

- `P002739-01` · Qwen / problem: Qwen không giữ hạn chế phải có ground-truth bounding boxes của cách làm trước; một nhãn còn dùng đại từ them thiếu đối tượng.
- `P002739-02` · Qwen / contribution: Qwen chỉ giữ kết quả vượt SOTA, bỏ joint method và finding hai bài toán hỗ trợ nhau.
- `P002739-03` · Qwen / dataset: Hai dataset chỉ được mô tả, không có tên trong abstract.
- `P002739-04` · Tham chiếu / contribution: Kết quả vượt SOTA trên cả person segmentation và identification có nguồn nhưng thiếu ở reference.
- `P002739-05` · Chưa chốt / task: Reference gộp person segmentation/identification trong một nhãn, Qwen tách theo hai tình huống camera. Không thể lấy hai cặp làm hai TP khi gold chỉ có một nhãn.

**P002814 — Gender Prediction in English-Hindi Code-Mixed Social Media Content : Corpus and Baseline System**

- `P002814-01` · Qwen / problem: Qwen chọn câu giới thiệu sự phổ biến của author profiling, bỏ các khó khăn spelling/grammar/transliteration và thiếu dữ liệu code-mixed.
- `P002814-02` · Qwen / task: Language identification là thao tác nghiên cứu nhưng chỉ xuất hiện trong contribution của Qwen, thiếu trong task.
- `P002814-03` · Qwen / dataset: Corpus English-Hindi từ Twitter là mô tả, chưa phải tên tài nguyên.
- `P002814-04` · Ghép embedding / method: Supervised classification baseline system và supervised classification xác định cùng cách tiếp cận; nhãn dài không đổi thuật toán. Cosine 0.8369; không ghép.
- `P002814-05` · Ghép embedding / contribution: Hai nhãn cùng artifact corpus English-Hindi mới; nhãn dài giữ thêm nguồn Twitter và annotation giới tính. Cosine 0.7822; không ghép.

**P002925 — Thou shalt not hate: Countering Online Hate Speech**

- `P002925-01` · Qwen / contribution: Qwen giữ dataset và model nhưng bỏ finding counterspeech nhận nhiều likes hơn.
- `P002925-02` · Qwen / dataset: Dataset counterspeech được mô tả bằng nội dung/nguồn YouTube, chưa có tên tài nguyên.
- `P002925-03` · Tham chiếu / contribution: Reference bỏ các classifier mới và F1 0.71/0.60 được nguồn/Qwen nêu.
- `P002925-04` · Tham chiếu / contribution: 13,924 manually annotated comments là thuộc tính số lượng của dataset đã có nhãn, không phải một artifact thứ hai.
- `P002925-05` · Ghép embedding / task: Evaluator ghép nghiên cứu cấu trúc ngôn ngữ với phát hiện loại counterspeech. Đây là phân tích mô tả và phân loại, hai thao tác khác nhau. Cosine 0.8525; đã ghép.
- `P002925-06` · Ghép embedding / task: Nhãn dài đúng thao tác tự động phát hiện counterspeech nhưng chỉ thiếu ngưỡng 0.85 một khoảng nhỏ. Cosine 0.8487; không ghép.

**P003096 — Incorporating Structured Commonsense Knowledge in Story Completion**

- `P003096-01` · Qwen / contribution: Qwen chỉ ghi vượt SOTA nói chung, bỏ artifact neural model và finding riêng về lợi ích của commonsense.
- `P003096-02` · Qwen / method: Nhãn neural model chung không giữ ba loại tín hiệu được tích hợp.
- `P003096-03` · Tham chiếu / task: Trong bài, story ending prediction và story ending selection cùng thao tác chọn ending. Hai nhãn reference làm một Qwen task đúng chỉ ghép được một lần.

**P003343 — RespNet: A deep learning model for extraction of respiration from photoplethysmogram**

- `P003343-01` · Qwen / dataset: Hai mô tả dataset không có tên và cùng nói đến hai dataset của thí nghiệm; không nên tính thành hai named resources.
- `P003343-02` · Tham chiếu / problem: Reference bỏ khoảng trống nghiên cứu chỉ ước lượng respiration rate thay vì toàn bộ signal; Qwen và nguồn đều nêu.
- `P003343-03` · Ghép embedding / contribution: RespNet và mô tả mạng mới called RespNet là cùng artifact. Cosine 0.8118; không ghép.
- `P003343-04` · Ghép embedding / problem: Câu dài và nhãn ngắn cùng trở ngại kích thước và chi phí hệ thống monitoring. Cosine 0.6778; không ghép.
- `P003343-05` · Chưa chốt / method: Conventional signal processing approaches là phương pháp đối chứng được thử nghiệm. Cần thống nhất quy tắc có đưa baseline thực sự chạy vào method hay không.

**P003677 — Incorporating popularity in topic models for social network analysis**

- `P003677-01` · Qwen / task: Qwen ghi thiết kế popularity component/extensions thay vì task topic modeling cho mạng xã hội.
- `P003677-02` · Qwen / contribution: Qwen giữ finding perplexity nhưng bỏ artifact popularity component và topic model extensions.
- `P003677-03` · Qwen / dataset: Real-world Twitter dataset chưa có tên riêng theo chính sách dataset hiện hành.
- `P003677-04` · Ghép embedding / problem: Nguồn xác định popularity problem do incoming edge degree cao; Qwen thêm nguyên nhân vào cùng tên vấn đề. Cosine 0.7764; không ghép.

**P003998 — Learning Sentiment-Specific Word Embedding for Twitter Sentiment Classification**

- `P003998-01` · Qwen / contribution: Qwen giữ finding hiệu năng, bỏ artifact mới SSWE khỏi contribution.
- `P003998-02` · Qwen / method: Qwen chỉ nêu ba neural networks, chưa giữ SSWE và distant supervision bằng emoticons.
- `P003998-03` · Tham chiếu / contribution: Nguồn đặt acronym SSWE trực tiếp cho sentimentspecific word embedding. Hai reference labels là một artifact.
- `P003998-04` · Tham chiếu / contribution: Reference chỉ ghi artifact và acronym, thiếu hai kết quả SSWE so với handcrafted features và khi concatenate features.
- `P003998-05` · Ghép embedding / dataset: Nhãn mô tả benchmark sentiment classification trong SemEval 2013 và tên SemEval 2013 đồng chỉ tài nguyên được dùng. Cosine 0.7801; không ghép.
- `P003998-06` · Ghép embedding / method: Hai nhãn cùng ba neural networks được phát triển; nhãn dài giữ thêm tín hiệu supervision. Cosine 0.6655; không ghép.


### 4 ví dụ đã bàn

**P000406 — Training Neural Network Language Models on Very Large Corpora**

- `P000406-01` · Qwen / method: New algorithms không xác định được neural network language model hay estimation in continuous space.
- `P000406-02` · Qwen / contribution: Qwen chỉ giữ cải thiện word error, bỏ artifact thuật toán huấn luyện mới trên corpus rất lớn.
- `P000406-03` · Qwen / dataset: Very large text corpora chỉ là mô tả quy mô, không phải tên dataset.

**P000474 — Evaluating a probabilistic model for cross-lingual information retrieval**

- `P000474-01` · Qwen / contribution: Nhãn 90% và 85% đứng riêng thiếu ngôn ngữ, tài nguyên và mức xấp xỉ. Nhãn slightly better than MT bỏ điều kiện improvement không significant.
- `P000474-02` · Qwen / method: Qwen bỏ mixture model dùng khi phối hợp hai nguồn.
- `P000474-03` · Qwen / dataset: Bilingual word list và parallel/pseudo-parallel corpus chỉ là loại tài nguyên, chưa có tên.

**P001274 — Leveraging Preposition Ambiguity to Assess Compositional Distributional Models of Semantics**

- `P001274-01` · Qwen / contribution: Qwen giữ các findings nhưng bỏ hai artifact mới là phương pháp đánh giá và dataset.
- `P001274-02` · Qwen / dataset: Dataset mới chỉ được mô tả theo công dụng, chưa được gọi tên.
- `P001274-03` · Tham chiếu / contribution: Hai findings có nguồn rõ ràng và được Qwen trích nhưng reference không giữ: neural input vectors tốt hơn co-occurrence và CDSM bắt được compositional information.
- `P001274-04` · Ghép embedding / problem: Hai nhãn cùng hạn chế metric không kiểm soát lexical confound; câu dài giữ thêm hệ quả khó diễn giải thí nghiệm. Cosine 0.6463; không ghép.

**P003063 — Exploiting Deep Representations for Neural Machine Translation**

- `P003063-01` · Qwen / task: Qwen ghi expose signals bằng layer aggregation, bỏ task neural machine translation.
- `P003063-02` · Qwen / contribution: Auxiliary regularization term là artifact mới nhưng chỉ có trong method của Qwen, thiếu ở contribution.
- `P003063-03` · Ghép embedding / contribution: Hai nhãn cùng layer aggregation và multi-layer attention mới; câu dài thêm mục đích expose signals. Cosine 0.8350; không ghép.


### 5 bài pending nguồn

**P000042 — A Closer Look at Few-shot Classification**

- `P000042-01` · Qwen / method: Qwen chỉ giữ modified baseline, bỏ các kỹ thuật được nguồn phân tích/thử là deeper backbones và standard fine-tuning.
- `P000042-02` · Ghép embedding / contribution: Mô tả dài và ngắn cùng consistent comparative analysis được trình bày. Cosine 0.6021; không ghép.
- `P000042-03` · Ghép embedding / contribution: Mô tả dài và ngắn cùng new experimental setting đánh giá cross-domain generalization. Cosine 0.6474; không ghép.
- `P000042-04` · Chưa chốt / dataset: Nguồn còn macro \miniI; chưa xác minh tên dataset đầy đủ nên không tự suy đoán hoặc kết luận Qwen hallucinate.

**P001758 — Learning Context-Dependent Mappings from Sentences to Logical Form**

- `P001758-01` · Qwen / method: Qwen chỉ ghi thuật toán có tên đang nghi lỗi nguồn, bỏ context-dependent pipeline và linear model nêu rõ trong abstract.
- `P001758-02` · Tham chiếu / contribution: Reference bỏ finding phục hồi logical form hoàn toàn đúng với accuracy 83.7%.
- `P001758-03` · Ghép embedding / dataset: ATIS corpus và ATIS là cùng tài nguyên; không có đổi dataset. Cosine 0.6341; không ghép.
- `P001758-04` · Chưa chốt / method: Nguồn ghi perception algorithm; không đủ chứng cứ từ abstract để tự sửa thành tên thuật toán khác.

**P002171 — Automated Music Emotion Recognition: A Systematic Evaluation**

- `P002171-01` · Qwen / method: Architecture described là tham chiếu hồi chỉ, không giữ cấu trúc AV regression, low-level features hay bag-of-frames được nguồn mô tả.
- `P002171-02` · Qwen / task: Maximize prediction performance thiếu đối tượng music emotion recognition; không tự xác định được nhiệm vụ.
- `P002171-03` · Qwen / dataset: Carefully constructed data set là mô tả chất lượng, chưa có tên.
- `P002171-04` · Chưa chốt / contribution: Abstract dừng giữa câu; chỉ kết luận trên phần nhìn thấy, không thể rà tính đầy đủ của findings ở phần bị cắt.

**P003362 — Verbnet: a broad-coverage, comprehensive verb lexicon**

- `P003362-01` · Qwen / dataset: Qwen bỏ trống dataset dù nguồn gọi tên VerbNet, PropBank, WordNet và Xtag là các tài nguyên được xây dựng/đối chiếu.
- `P003362-02` · Qwen / contribution: Qwen giữ mappings và kết quả, nhưng bỏ artifact chính là VerbNet.
- `P003362-03` · Tham chiếu / task: Nguồn nói animation là một ứng dụng của VerbNet, chưa chứng minh đây là task nghiên cứu được thực hiện trong bài. Reference đang đưa application này vào task.
- `P003362-04` · Tham chiếu / contribution: Finding có thể semi-automatically bổ sung/tinh chỉnh VerbNet từ corpus có nguồn nhưng thiếu ở reference.
- `P003362-05` · Chưa chốt / contribution: Nguồn ghi FameNet II; chưa xác minh lỗi chữ nên không tự thay tên hoặc dùng mục này làm lỗi extraction.

**P004138 — Cosegmentation and Cosketch by Unsupervised Learning**

- `P004138-01` · Qwen / problem: Qwen ghi định nghĩa co-segmentation thay vì trở ngại căn chỉnh common objects mà nguồn nêu.
- `P004138-02` · Qwen / contribution: Qwen chỉ giữ finding outperform, bỏ các artifact framework, co sketch và Coseg-Rep được giới thiệu.
- `P004138-03` · Ghép embedding / dataset: A new dataset called Coseg-Rep và Coseg-Rep rõ ràng là cùng dataset. Cosine 0.8284; không ghép.
- `P004138-04` · Ghép embedding / method: Hai nhãn cùng statistical model; câu dài giữ thêm nội dung energy coupling của chính model này. Cosine 0.6649; không ghép.
- `P004138-05` · Chưa chốt / dataset: Nguồn ghi iciest chưa xác minh; Qwen còn gộp MSRC và tên này thành một nhãn. Cần kiểm tra nguồn rồi tách từng resource.

## Dữ liệu giữ lại và kiểm tra

- [Sổ audit JSONL](../../../data/exp_a/evaluation/sample_audit/audit.jsonl): 29 record theo bài, đủ năm facet đã rà, ghi chú nguồn và 121 nhận định có dẫn chứng.
- [Summary/manifest](../../../data/exp_a/evaluation/sample_audit/summary.json): seed/ID, thống kê tách nhóm, provenance encoder, hash input/output và kết quả kiểm tra.
- Đã dùng lại encoder trong `evaluate_exp_a.py`, không thêm script audit/probe riêng. Bốn file selection, source-first notes, candidate scores và runtime trung gian được gộp vào hai file dữ liệu trên rồi xóa.
- Kiểm tra máy: tái lập ID mẫu, nhãn dẫn chiếu tồn tại đúng paper/facet, quote có nguyên văn trong nguồn, các cặp matcher đúng trạng thái ghép, thống kê tái tính được và hash input/output 400 bài không đổi.

Không chạy lại trích xuất hay đổi điểm 400 bài trong lượt này. Kiểm tra dữ liệu và hash xác nhận tính nhất quán kỹ thuật; không tự xác nhận mọi nhận định ngữ nghĩa là đúng.
