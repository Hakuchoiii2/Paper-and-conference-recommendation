# Pilot50 v3.6 — review và dataset

**Cập nhật sau chạy:** kernel version8 đã COMPLETE, đủ50 bài và replay/hash qua.
Micro-F1 **53,85%**, dataset **80,00%**, method **58,30%**; đã giữ whether nhưng
còn hồi quy scope ở P002586 và bỏ negative BLEU finding P004047.
Xem [đánh giá output và đối chiếu lỗi cũ](KAGGLE_PILOT50_V3_6_EVALUATION_2026-10-16.md).
Các mục bên dưới ghi trạng thái và kiểm tra tại thời điểm chuẩn bị/push.

Người dùng đã yêu cầu sửa tiếp và push. Mốc so là prompt3.5/kernel7 đã
COMPLETE: problem F1 43,14%, dataset36,36%, micro53,88% trên cùng50 bài và
AI reference. Đây là cohort phát triển, chưa phải human-confirmed semantic F1.

## Thay đổi

- Giữ nguyên hướng problem3.5. Dataset đọc toàn bộ title/abstract, kể cả câu
  findings; tách tên resource và phiên bản độc lập. Ưu tiên tên ngắn trong nguồn
  thay vì thêm descriptor làm đảo thứ tự từ. Không chèn tên/ID/đáp án của pilot
  vào prompt. Game, ngôn ngữ và dữ liệu chung từ repository không đủ là tên dataset.
- Review3.6 chỉ áp dụng thay đổi vào problem/dataset và các facet có lỗi ở attempt
  trước. Các facet khác hợp lệ theo validator được giữ nguyên từ output trước.
  Model vẫn trả đủ JSON để kiểm schema; schema sai không được che bằng merge.
  Nếu attempt trước sai schema, toàn bộ facet được phép sửa ở lượt tiếp theo.
- Khi applied selection và lỗi không đổi, request review cuối có phản hồi khác,
  yêu cầu dựng lại item từ evidence_options, giữ ý đúng và chọn lại evidence ID.
  Giữ ngân sách ba lượt và greedy decoding, không chỉ đổi seed để mong có lời giải mới.
- Khi toàn bộ tuple điểm baseline bằng nhau, 3.6 ưu tiên review/lượt mới hơn.
  Không đổi công thức score hoặc thứ tự tiêu chí cũ. Các version3.1–3.5 giữ nguyên
  acceptance/ranking gốc khi replay.
- Bổ sung guard3.6 cho problem nếu evidence có cấu trúc investigate/examine/...whether
  mà concept bỏ whether. Guard là heuristic cho câu hỏi tường minh, không chứng minh
  mọi problem đều đúng vai trò. Không thay evaluator/matcher để tăng điểm.
- Audit ghi riêng `raw_output`, `applied_output`, `review_facets`. Replay áp dụng
  scope lại theo thứ tự raw attempts, kiểm nội dung applied rồi tính lại score/lỗi;
  sửa audit hoặc che schema error sẽ bị từ chối. Metadata ghi
  `review_application=facet_scoped_v3_6`.

Tradeoff: facet hợp lệ về từ/evidence có thể vẫn sai nghĩa hoặc bỏ sót; scoped
review sẽ giữ các facet đó. Cần đánh giá riêng sự bảo toàn và coverage, không
coi validator pass là semantic correctness. Problem/dataset vẫn được review
toàn list nên cũng còn rủi ro mất ý trong chính hai facet này.

## Kiểm tra trước push

165 test qua: 88 project +77 expA. Sáu test3.6 bao gồm raw P003673 thực tế,
giữ whether, tiebreak cũ/mới, không mất facet hợp lệ, sửa facet lỗi, schema sai
không bị che và audit tamper. Test dualT4 đã chạy luồng export/merge/resume3.6
với fake GPU inference; không đo chất lượng câu trả lời model.

Năm output3.1–3.5 replay đủ50 bài mỗi bản. Review độc lập không có blocker.
Bundle13 file, không có output cũ hoặc reference. Corpus, model/revision/NF4,
seed42, cohort50 ID, guideline3.1, filter named-resource và evaluator/reference/
ngưỡng0,85 giữ nguyên. Engine3.7 thêm routing và các hash legacy xác định;
không được resume annotation3.5 thành3.6.

## Thử offline chỉ đổi tiebreak

Trên raw3.5 đã lưu, thay tiebreak chọn21 attempt khác, trong đó chỉ3 bài thay
nội dung nhãn; micro vẫn **53,8787%**, TP/FP/FN **191/116/211**. P003673 giữ
câu hỏi whether đã được review sửa đúng. Matcher cũ vẫn nhận cả assertion sai
là TP, nên chỉ số không phản ánh cải thiện này. Không chỉnh matcher trong lần thử.

Kết quả này chỉ kiểm tiebreak, không dự đoán hiệu quả prompt/scoped review mới.
Không tạo annotation mới giả làm output3.6. Bằng chứng:
`data/exp_a/evaluation/pilot50_v3_6_tie_ablation/summary.json`.

## Run mới

Đã push **kernel version 8**, CLI xác nhận **RUNNING**. Source tải lại khớp
SHA-256 bản gửi; metadata xác nhận private, GPU/Internet bật và machine_shape
`NvidiaTeslaT4`. Cấu hình hai worker; chưa có log runtime để xác nhận tên GPU thực tế.
Output riêng `data/exp_a/generated_v3_6_pilot50/`,
hai shard `generated_v3_6_pilot50_parts/gpu_0/` và `gpu_1/`, 25 bài/GPU trên
T4 ×2. Không resume kết quả cũ. Chưa có điểm semantic3.6.

Sau khi COMPLETE: kiểm remote source/input hashes, đủ50 ID, replay raw/applied
audit, chấm cùng reference và rà riêng whether, dataset trong câu findings,
resource bị gộp, số review lặp và các facet bị cố định nhưng còn thiếu ý.

[Xác minh push](../../../data/exp_a/.kaggle/review/pilot50_v3_6_push_verification.json).
