# Exp A: so sánh model và cách trích xuất trong một kernel

Kernel riêng tư: [Exp A Qwen Facet Matrix](https://www.kaggle.com/code/htnkhi/exp-a-qwen-facet-matrix).
**[Version 2 COMPLETE và đã chấm lại](KAGGLE_FACET_MATRIX_V2_EVALUATION_2026-10-16.md)**:
đủ 200/200 kết quả, 200 replay và 1.000 paper-facet checks khớp local.
P001604 đã qua, không lặp CUDA OOM. 8B original cao nhất: micro 56,36%, macro 56,89%.
Hai nhánh tách facet giảm điểm; xem report để phân biệt lỗi schema và lỗi ngữ nghĩa.

**Version 1 ERROR** ngày 2026-10-16: hoàn tất 50/50 4B source-first,
17/50 8B original và 16/50 8B source-first trước khi CUDA OOM tại bài P001604.
Version 2 phục hồi nguyên 50 kết quả 4B đã kiểm tra và chạy lại cả hai nhánh 8B.
189 test qua trước push; source tải lại khớp local; payload/signature đã xác minh.

| Cấu hình | Method/contribution | Problem/task/dataset | Nguồn kết quả |
|---|---|---|---|
| 4b_original | V3.7 extract + review | V3.7 | Tái sử dụng kernel pilot version 9 đã hoàn tất |
| 4b_source_first | Hai lượt riêng đọc nguồn, chọn evidence span rồi concept | Kế thừa 4b_original | Tái sử dụng 50 kết quả matrix v1, hash và raw/applied replay qua |
| 8b_original | V3.7 extract + review | V3.7 | Chạy mới |
| 8b_source_first | Hai lượt riêng đọc nguồn, chọn evidence span rồi concept | Kế thừa 8b_original | Chạy mới |

Tất cả dùng cùng 50 paper IDs, title/abstract nguyên bản và reference AI source-only v1
đã đóng băng. Đây là tập phát triển đã được dùng nhiều lần; chưa có human gold hay
kiểm tra trên bài mới. Không dùng các nhãn reference làm prompt/example hoặc feedback.
Reference chỉ được đọc trong bước chấm sau khi các worker kết thúc.

Model 4B: `Qwen/Qwen3-4B-Instruct-2507`, revision
`cdbee75f17c01a7cc42f958dc650907174af0554`.
Model 8B: `Qwen/Qwen3-8B`, revision
`b968826d9c46dd6066d109eabc6255188de91218`.
Model 8B được tắt thinking theo [hướng dẫn chính thức](https://huggingface.co/Qwen/Qwen3-8B).
Hai model khác cả post-training, nên đây không phải phép đo chỉ thay số tham số.
Cả hai dùng NF4 double, FP16 compute, greedy, seed 42, tối đa 2048 token/lượt.

V1 dùng SDPA mặc định. Transformers bật native GQA khi không có attention mask;
[PyTorch chỉ hỗ trợ native GQA trên Flash và math backend](https://docs.pytorch.org/docs/2.8/generated/torch.nn.functional.scaled_dot_product_attention.html).
Ở T4, attention dài rơi vào math backend, tạo tensor FP32 bậc hai theo độ dài.
Log ghi yêu cầu thêm 3.73 GiB, GPU chỉ còn 3.25 GiB, dừng ở review P001604.
V2 chỉ đổi backend 8B: mở rộng KV heads rồi dùng efficient SDPA với native GQA tắt,
đăng ký cả attention function và SDPA mask qua AttentionInterface. Causal mask,
padding và KV cache đã được so với Qwen3 nhỏ thật; không cắt nguồn hay giảm output budget.
Các kết quả 8B dở của v1 được giữ riêng, không trộn vào hai nhánh 8B v2.
Floating-point có thể khác giữa backend, nên cả hai nhánh 8B được chạy lại.

Probe CUDA local với Q=[1,32,5600,128], KV=[1,8,5600,128]:
math peak 9,651,535,360 bytes; efficient peak 238,944,256 bytes. Đây là phép đo
một attention operation trên RTX4060, chưa phải tổng VRAM model hoặc kiểm chứng T4 hoàn chỉnh.
8B bắt đầu với P001604 ở GPU0 để kiểm tra bài đã lỗi sớm.

Source-first tách method/contribution thành context độc lập, không xem bản nháp.
Contribution chia vai trò artifact/finding trong audit. Mỗi item có evidence_id,
span nguyên văn và concept bằng từ trong span theo thứ tự nguồn; không sửa abstract lỗi.
Riêng finding dùng guard điều kiện đầu câu policy 3.2 và guard phủ định theo clause,
kể cả `doesn't/isn't`; artifact giữ tên gọn. Đây là một phần thay đổi workflow,
không áp dụng ngược vào original. Guard clause dùng heuristic, chưa chứng minh đúng ngữ nghĩa.
Tối đa một lượt sửa lỗi cho mỗi facet. Item không hợp lệ không được công bố;
kết quả hết lượt sửa vẫn ghi fallback, không được nhận là validation passed.
Độ đầy đủ và đúng vai trò vẫn cần rà ngữ nghĩa, không thể chứng minh bằng validator.

Hai GPU T4 xử lý các phần 25 bài không trùng, lần lượt pha 4B rồi 8B.
8B được nạp một lần/worker để dùng cho cả original và source-first.
Mỗi bài hoàn tất được lưu checkpoint nguyên tử có signature và checksum;
thiếu bài, sai hash, sai IDs hoặc worker lỗi sẽ không xuất bảng COMPLETE.

Chấm bằng cùng `evaluate_exp_a.py`: Qwen3-Embedding-0.6B pinned, threshold 0.85,
one-to-one matching và cùng các guard. Baseline phải khớp TP=200, FP=135, FN=202.
Kiểm tra local với embedding thật đã khớp micro 54.274084%, macro 56.205044%
và toàn bộ 250 phép so sánh theo bài/facet.

Output chính trong `exp_a_matrix/results/`:

- `experiment_table.csv` và `experiment_table.md`: precision, recall, micro/macro F1,
  từng facet, F1 gộp method/contribution, token, thời gian generation và fallback.
- `<arm>/evaluation.json`: các nhãn extra/missing/matched và cặp bị guard chặn theo bài.
- `<arm>/records/<paper_id>.json`: kết quả, evidence span và raw generation audit.
- `experiment_summary.json`: trạng thái, bảng, model/evaluator/reference hashes.

Generation seconds là tổng thời gian gọi model trên các bài/GPU, không phải wall time.
Chi phí source-first cộng cả original cần để cung cấp ba facet kế thừa.
Original 4B là cache nên không dùng runtime của nó để kết luận tốc độ giữa model.
Không chọn winner tự động chỉ bằng micro F1; cần xem precision, target F1 và lỗi tái diễn.

Chạy từ thư mục project:

```powershell
& data/exp_a/.kaggle/matrix/matrix.ps1 -Action build
& data/exp_a/.kaggle/matrix/matrix.ps1 -Action push
& data/exp_a/.kaggle/matrix/matrix.ps1 -Action status
& data/exp_a/.kaggle/matrix/matrix.ps1 -Action download
```

Bundle được tạo riêng với corpus 50 bài; không ghi đè bundle/output pilot v3.7.
Mỗi lần download có thư mục timestamp riêng, giữ log các lần chạy tách biệt.
Embedding tokenizer/config đã được đóng gói từ cache đã xác minh; weights evaluator
được tải đúng revision và kiểm tra SHA256 ở Kaggle. Không gửi credential vào bundle.
