# Pilot50 v3.2 — hồi quy so với v3.1

Kernel version 3 đã COMPLETE; tải output bằng Kaggle CLI. Lưu đủ 50 bài,
không có ID thiếu/failed. Metadata giữ đủ 138 raw generations. Hash hai JSONL,
provenance, selection và replay validator đều qua bằng `load_silver(complete=True)`.
Output chuẩn ở `data/exp_a/generated_v3_2_pilot50/`; giữ v3.1 làm đối chứng.

## Kết quả cùng điều kiện đánh giá

Giữ nguyên 50 ID, reference AI source-only, evaluator, encoder và ngưỡng 0.85.
Reference có 402 concept; hash reference và evaluator khớp lần v3.1.

| Chỉ số | Silver gốc | v3.1 | v3.2 |
|---|---:|---:|---:|
| Precision | 48,72% | 55,72% | 40,06% |
| Recall | 33,08% | 46,02% | 32,59% |
| Micro F1 | 39,41% | 50,41% | **35,94%** |
| TP / FP / FN | 133 / 140 / 269 | 185 / 147 / 217 | 131 / 196 / 271 |
| Qua validation / fallback | — | 26 / 24 | 17 / 33 |

F1 giảm **14,47 điểm phần trăm** so với v3.1, thấp hơn silver gốc 3,47 điểm.
Không nên dùng v3.2 làm bản thay thế v3.1 hoặc chạy toàn bộ 4.210 bài.
Contribution gần như giữ nguyên; phần giảm chủ yếu đến từ method và task.

| Facet | F1 v3.1 | F1 v3.2 | Thay đổi (điểm %) |
|---|---:|---:|---:|
| Problem | 38,60% | 25,32% | −13,28 |
| Task | 52,55% | 35,82% | −16,73 |
| Method | 51,82% | **22,32%** | **−29,50** |
| Dataset | 50,00% | 40,91% | −9,09 |
| Contribution | 50,62% | 50,81% | +0,18 |

Theo số TP từng bài, 29 bài giảm, 15 bằng và 6 tăng. Thời gian sinh là
4.644,59 giây (~77,4 phút), so với ~55,3 phút của v3.1.

## Những lỗi quan sát được

1. **Method bị gộp và kéo dài.** Số nhãn method giảm 103 → 80; độ dài trung vị
   tăng 5 → 16,5 từ. TP method giảm 64 → 25, chiếm 39 trong 54 TP bị mất ròng.
   P001963 trước đây tách TTR-LDA-Community, LDA, Girvan-Newman và inference
   mechanism; v3.2 gộp cả bốn vào một câu 26 từ và không ghép được nhãn method nào.
   Đây là vấn đề độ chi tiết của extraction và phép ghép một–một; không có nghĩa
   mọi kỹ thuật được nhắc trong câu dài đều đã biến mất về mặt ngữ nghĩa.
2. **Problem bị suy diễn thành câu hỏi.** Nhãn problem tăng 26 → 48, trong khi
   TP giảm 11 → 10 và FP tăng 15 → 38. Có 12 nhãn thêm `whether` dù evidence
   không có từ đó. Ví dụ P000669 biến câu tác giả phân tích vai trò semantic roles
   thành câu hỏi “whether semantic roles improve …”. Giữ trạng thái câu hỏi khi
   nguồn có câu hỏi không đồng nghĩa với tạo câu hỏi cho mọi bài.
3. **Review chưa sửa được lỗi đã báo.** Trong output được chọn, 59 item ở 27 bài
   vi phạm source words/order, gồm 20 contribution, 16 problem, 11 task, 10 method
   và 2 dataset. Một phần là paraphrase/ghép nhiều evidence; một phần sửa OCR trái
   quy tắc giữ nguồn. Các lỗi này không tự chứng minh tất cả nhãn sai ngữ nghĩa.
   Tuy vậy, vòng review vẫn giữ lỗi qua ngân sách ba lượt, làm 33 bài fallback.
4. **Dataset guard phát hiện lỗi nhưng model vẫn sinh nhãn đó.** Có 14 item ở 14
   bài bị chặn vì không phải resource có tên: `annotated Arabic corpus`,
   `Dutch test collection`, `biomedical abstracts`… Dataset TP giảm 13 → 9,
   FP chỉ giảm 23 → 19. Thêm validator chưa đủ cải thiện extraction.
5. **Nguồn có vấn đề vẫn cần review.** Có 5 bài được gắn cờ: P001996, P002586,
   P004047 (encoding/tách từ), P003491 (book/download boilerplate), P003614
   (abstract có dấu hiệu cụt). Cờ mới không phải bằng chứng nguồn vừa hỏng thêm.

Đã đọc đối chiếu cụ thể P001963, P001589, P003441 và các lỗi whether/dataset
trong metadata. Prompt, scoring, ranking và guard đã thay đổi cùng một lượt.
Phần thử offline bên dưới tách được cách chọn/lọc trên output đã lưu; chưa có
ablation sinh lại để quy toàn bộ hồi quy cho từng thay đổi prompt hoặc feedback.
139 unit test qua chỉ xác nhận hành vi code với fixture, chưa xác nhận chất lượng
đầu ra Qwen trên dữ liệu thật.

## Hướng sửa tiếp theo

- Lấy prompt v3.1 làm mốc, thêm từng thay đổi riêng; ưu tiên giữ method/task là
  cụm ngắn, tách kỹ thuật độc lập và tái sử dụng cùng evidence ID cho nhiều nhãn.
  Thêm ví dụ JSON cụ thể cho câu chứa nhiều method; giữ điều kiện dài ở finding
  khi cần, tránh áp cách viết finding lên mọi facet.
- Problem chỉ lấy limitation/question được nguồn nêu rõ; nếu không có thì `[]`.
  Chỉ giữ `whether` khi nó có trong evidence, không thêm mới để diễn đạt lại.
- Retry tập trung vào item lỗi, yêu cầu trích span có thật và không đưa lại nhãn
  dataset vừa bị từ chối. Nếu hết lượt vẫn lỗi, tiếp tục giữ audit/review flag;
  không diễn giải bản fallback là đã hợp lệ.
- So riêng prompt và cách chọn attempt trên pilot hiện tại. Giữ reference,
  matcher và ngưỡng để so công bằng; sau khi dev cải thiện, kiểm tra cohort mới
  trước khi mở rộng toàn corpus.

## Bằng chứng và giới hạn

- [Đánh giá v3.2](../../../data/exp_a/evaluation/pilot50_v3_2_ai_v1/report.md):
  summary, per-paper evidence và manifest nằm cùng thư mục.
- [So sánh ba lượt](../../../data/exp_a/evaluation/pilot50_comparison_ai_v1/comparison.json).
- [Trạng thái và hash output](../../../data/exp_a/.kaggle/pilot/push_report.json),
  [kiểm tra provenance/replay](../../../data/exp_a/.kaggle/pilot/verification.json).

Điểm là embedding agreement với reference AI, chưa phải semantic accuracy được
người xác nhận. Pilot50 đã dùng phát triển bản sửa, nên đây là phép so trên dev.
Không đổi nhãn tham chiếu hoặc matcher để bù cho hồi quy. Đã giữ raw generations
trong metadata; bản tải trùng, ZIP tải dở, cache và log thử tải được dọn sau kiểm tra.

## Thử từng thay đổi offline — không chạy lại generator

Dùng đủ 129 raw attempt v3.1 và 138 raw attempt v3.2. Chỉ chạy lại encoder local
và phép ghép hiện hành với reference/threshold giữ nguyên. Không gọi Qwen trích
xuất, không push Kaggle. Không sửa output chuẩn, code generator, evaluator hoặc
reference. Mọi phương án xử lý đủ 50 bài.

Đã kiểm tra tái hiện đúng selected attempt, nhãn, TP/FP/FN và micro F1 của cả hai
lượt gốc. Phép thay từng facet cũng được kiểm tra bằng cộng/trừ counts độc lập
giữa các facet. Input hashes giữ nguyên trước/sau. Kết quả từng phương án,
selected attempt theo ID và index các item bị lọc nằm trong trường
`offline_ablation` của [comparison.json](../../../data/exp_a/evaluation/pilot50_comparison_ai_v1/comparison.json).

### Thay đổi từng phần trên nền v3.1

Mỗi dòng dưới áp dụng độc lập lên v3.1, trừ dòng kết hợp cuối. “Lọc dataset”
chỉ bỏ item mà validator 3.2 trả lỗi `dataset requires an explicit named resource`;
không nhìn gold để chọn item cần bỏ. “Lọc mọi item lỗi” kiểm tra từng item riêng,
không xóa cả paper chỉ vì có cờ fallback.

| Phương án | TP | FP | FN | Micro F1 | So với v3.1 (điểm %) |
|---|---:|---:|---:|---:|---:|
| v3.1 gốc | 185 | 147 | 217 | 50,41% | — |
| Chỉ scoring mới | 184 | 146 | 218 | 50,27% | −0,14 |
| Chỉ ranking/tie-break mới | 184 | 148 | 218 | 50,14% | −0,27 |
| Scoring + ranking mới | 183 | 147 | 219 | 50,00% | −0,41 |
| Validator mới, chọn lại attempt với scoring/ranking cũ | 185 | 141 | 217 | 50,82% | +0,42 |
| Toàn bộ validator/scoring/ranking mới trên raw v3.1 | 183 | 141 | 219 | 50,41% | +0,00 |
| Chỉ lọc dataset không có tên resource | **185** | **126** | **217** | **51,89%** | **+1,48** |
| Chỉ lọc problem vi phạm validator | 182 | 142 | 220 | 50,14% | −0,27 |
| Lọc mọi item vi phạm validator | 162 | 100 | 240 | 48,80% | −1,61 |
| Dataset filter + contribution lấy từ v3.2 | 187 | 131 | 215 | 51,94% | +1,54 |

Bộ lọc dataset loại 21 FP và giữ nguyên TP/recall theo matcher hiện hành; đây là
phần đáng giữ nhất. Scoring/ranking mới chưa có lợi trên tập attempt v3.1.
Lọc mọi lỗi lexical làm mất cả nhãn vẫn khớp reference, nên không được dùng như
một bộ lọc ngữ nghĩa tổng quát. Thêm contribution v3.2 sau dataset filter chỉ
tăng thêm khoảng 0,05 điểm %, chưa đủ để ưu tiên một pipeline ghép hai phiên bản.

### Thay lần lượt từng facet bằng nhãn v3.2

Giữ bốn facet còn lại từ v3.1. Đây là phép thử chọn kết quả theo facet, không
phải bằng chứng riêng cho một câu lệnh prompt.

| Facet thay bằng v3.2 | Micro F1 toàn bộ | So với v3.1 (điểm %) |
|---|---:|---:|
| Problem | 48,68% | −1,73 |
| Task | 47,33% | −3,08 |
| Method | 41,07% | −9,34 |
| Dataset | 49,86% | −0,55 |
| Contribution | 50,47% | +0,06 |

Method là phần gây giảm mạnh nhất; thay riêng contribution gần như không đổi.
Dataset *output* v3.2 kém hơn v3.1, trong khi quy tắc *lọc dataset* v3.2 áp lên
output v3.1 lại có lợi. Vì vậy không nên nhận hoặc bỏ cả phiên bản như một khối.

### Chọn lại các raw attempt v3.2

Thử đủ tám tổ hợp validator 3.1/3.2 × scoring 3.1/3.2 × ranking 3.1/3.2 trên
cùng các attempt đã quan sát. Mỗi tổ hợp lấy review sạch đầu tiên nếu có;
nếu không có thì chọn fallback theo ranking tương ứng, giống cách dừng của
production trong phạm vi những candidate đã lưu.

- Trên raw v3.2: dùng toàn bộ policy chọn của v3.1 đạt 34,79%; policy v3.2
  hiện hành đạt 35,94%, cũng là cao nhất trong tám tổ hợp này.
- Chỉ lọc dataset trên output v3.2 tăng 35,94% → 36,64% (bỏ 14 FP, giữ 131 TP).
- Lọc problem không hợp lệ đạt 35,62%; lọc mọi item lỗi còn 30,79%.

Như vậy, scoring/ranking không phải nguyên nhân chính của mức tụt ~14,47 điểm:
đổi chúng trên raw v3.2 không đưa điểm về gần 50,41%. Trong các phương án đã
thử, nút thắt chính nằm ở nội dung/độ chi tiết của candidate pool v3.2, bao gồm
ảnh hưởng prompt và feedback sinh ra pool đó. Cờ source-quality chỉ thêm metadata,
không đổi nhãn nên tự nó không làm F1 tăng.

### Kết luận sử dụng

Ưu tiên **v3.1 + bộ lọc dataset có tên resource** làm ứng viên cải thiện: 51,89%
trên pilot này, không cần một lượt sinh mới. Giữ cách trích method/task/problem
và scoring/ranking v3.1. Sau khi được chấp thuận, bản này đã được giữ trong
`generated_v3_1_filtered_pilot50/`, có audit/replay và config riêng với output
đối chứng. Xem [bản được giữ và lỗi v3.1 còn lại](KAGGLE_PILOT50_V3_1_EVALUATION_2026-10-15.md).
Các phương án lọc/ghép khác vẫn là phép thử trên dữ liệu đã lưu.

Các attempt v3.1/v3.2 từng nhận prompt/feedback và dừng khác nhau. Thử offline
không tạo ra candidate mà một policy khác có thể đã sinh, và không đo được
hiệu quả prompt mới chưa được chạy. Việc chọn phương án tốt sau khi xem điểm
trên pilot là chọn trên dev; reference vẫn là AI, chưa có human confirmation.
