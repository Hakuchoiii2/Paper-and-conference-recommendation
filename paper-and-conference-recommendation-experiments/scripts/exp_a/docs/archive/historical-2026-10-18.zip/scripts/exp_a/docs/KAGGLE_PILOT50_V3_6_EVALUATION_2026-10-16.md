# Pilot50 v3.6 — dataset phục hồi, tổng điểm gần như đứng yên

Kernel **version 8 / prompt 3.6 đã COMPLETE**. Chấm lại đủ 50 bài bằng cùng
reference AI v1, evaluator, Qwen3-Embedding-0.6B và ngưỡng 0,85: micro-F1
**53,8462%**, so với **53,8787%** ở v3.5, giảm **0,0325 điểm phần trăm**.
Dataset phục hồi mạnh nhưng method mất 8 TP; chưa có cải thiện tổng thể.

[Rà sâu chỗ tập trung lỗi và thứ tự sửa](KAGGLE_PILOT50_V3_6_PRIORITY_AUDIT_2026-10-16.md):
contribution/method chiếm69,75% FP+FN; đã triage65 contribution FN và đối chiếu
7 ca method rỗng với mọi raw attempt.

Đã kiểm counts của toàn cohort, đọc nguồn và selected labels của 50 bài, đối
chiếu raw/applied attempts ở các ca cũ và các hồi quy. Đây là kiểm tra của AI;
chưa adjudicate từng cặp tương đương của toàn bộ reference và chưa có human
semantic F1. FP/FN dưới đây là bất đồng theo matcher, không tự động là lỗi Qwen.

## Tính toàn vẹn của run

- Đủ **50/50 ID**, không missing/failed; hai **Tesla T4** thực tế, 25 bài/GPU.
  Inference và merge **2.218,96 giây (~37 phút)**.
- **127 generations**, **27 validation pass / 23 fallback**, so với 24/26 ở
  v3.5. Hai shard có status partial so với toàn cohort 50; bản merge complete.
- Source kernel tải lại khớp SHA-256 bản push v8; cả **13 file** source/input
  được đóng gói khớp snapshot. Bundle không chứa reference hoặc output cũ.
- Hai JSONL chuẩn khớp manifest và bản tải; replay raw/applied của merged50,
  cả hai shard25 và **50 attempt audit files** đều qua. Không có lỗi merge
  từng xảy ra ở kernel v5.
- Corpus, reference, evaluator, selection và output v3.1–v3.5 khớp hash trước
  push. Kiểm tra manifest của sáu lượt chấm xác nhận cùng reference/evaluator/
  encoder weights/revision/matcher/ngưỡng. Không đổi nhãn để tăng điểm.

Output chuẩn: `data/exp_a/generated_v3_6_pilot50/`; giữ hai shard ở
`data/exp_a/generated_v3_6_pilot50_parts/` và bản tải riêng dưới `.kaggle/review/`.

## Điểm cùng điều kiện chấm

| Facet | F1 v3.4 | F1 v3.5 | F1 v3.6 | TP / FP / FN v3.6 |
|---|---:|---:|---:|---:|
| Problem | 14,63% | 43,14% | **41,51%** | 11 / 11 / 20 |
| Task | 60,56% | 57,97% | **56,12%** | 39 / 16 / 45 |
| Method | 61,54% | 61,86% | **58,30%** | 65 / 14 / 79 |
| Dataset | 53,85% | 36,36% | **80,00%** | 12 / 2 / 4 |
| Contribution | 49,43% | 48,09% | **48,25%** | 62 / 68 / 65 |
| Micro | 53,82% | 53,88% | **53,85%** | 189 / 111 / 213 |

Micro precision **63,00%**, recall **47,01%**; macro-F1 **56,83%**; lexical
micro-F1 **23,08%**. Nhãn dự đoán 307 → 300; TP 191 → 189, FP 116 → 111,
FN 211 → 213. Dataset +8 TP bị bù bởi method −8, task −1, contribution −1.
Contribution F1 nhích lên do FP giảm nhiều hơn TP, không phải phục hồi thêm ý.

Theo F1 từng bài: **13 tăng, 9 giảm, 27 bằng**, 1 không xác định vì hai phía
đều rỗng. Bài duy nhất ghép đủ năm facet là P003491, nguồn boilerplate không
phải abstract nghiên cứu; không diễn giải thành một bài nghiên cứu hoàn hảo.

Các mốc micro trước đó: v3.1 **50,41%**, v3.1+filter **51,89%**, v3.2 **35,94%**,
v3.3 **52,57%**. V3.6 không lặp lại mức sụt method nghiêm trọng của v3.2,
nhưng cũng chưa vượt v3.5 hoặc phục hồi dataset tốt hơn mốc v3.1+filter (83,87%).

## Lỗi cũ: phần đã sửa và phần còn lại

| Vấn đề từng ghi nhận | Trạng thái ở v3.6 | Bằng chứng |
|---|---|---|
| Merge nhầm cohort ở kernel v5 | Đã khắc phục | Merge đủ50, hai tập25 không giao nhau, audit/hash qua |
| P003673 biến câu hỏi whether thành assertion | Đã sửa selected output | Draft vẫn viết does not learn; review2/3 giữ whether, chọn review3. Còn fallback lexical encoderdecoder/encoder-decoder |
| Chép ví dụ ranker/vocabulary vào draft | Không tái xuất hiện | Không có câu đó trong cả127 raw attempts; cũng đã sạch ở v3.5 |
| Bỏ named resource trong câu findings | Cải thiện rõ | P001903 phục hồi BioNLP2009/2011/2013 và BioCreative2017; P003085 Inria; P003565 Prague; P004047 Europarl |
| P002877 bỏ WMT15/Yelp | Sửa một phần | WMT15 có lại; Yelp vẫn thiếu |
| P003579 gộp NLPCC2014/Reuters | Chưa sửa | Draft tách2 nhưng sai word order; review gộp1 và pass, chỉ ghép được1 resource |
| False acceptance Dota/UCI | Chưa sửa | P003211 vẫn giữ brain data…Dota1; P003308 vẫn giữ real world data from UCI repository; chưa có tên dataset cụ thể |
| Self-review lặp | Giảm, chưa hết | Fallback có raw liền nhau giống hệt: 20/26 → **9/23**; còn11 ca applied selection/errors không đổi trước lượt cuối |
| P001431 trả toàn bộ rỗng | Sửa một phần | Có task/contribution, nhưng problem thiếu no standard definition và method vẫn rỗng dù có literature synthesis |
| Bỏ limitation / nhầm finding thành problem | Còn | P002652 bỏ known NP-hard; P002297 bỏ challenging dialogue; P003308/P003809 bỏ limitation; P000781 vẫn đưa finding moderator analysis sang problem |
| Bỏ artifact ở contribution | Còn | P001389 không ghi JTV; P001806 không ghi TARN; P003308 không ghi MCMM dù nguồn tuyên bố đề xuất |
| Bỏ negative BLEU finding P004047 | Hồi quy so với v3.5 | V3.5 có finding; v3.6 thiếu ở cả3 raw attempts, không thể phục hồi chỉ bằng chọn lại attempt |
| Guard phủ định sai phạm vi | Còn | P001181 vẫn báo drops source negation cho finding domain adaptation do trộn với background in-domain |
| Source detector bỏ sót | Còn | P001211 có bri le/a acks, P003614 bị cắt giữa câu, cả hai vẫn no_flag_detected |

Problem rỗng **36 → 35 bài**; số bài reference có problem nhưng prediction
rỗng **15 → 14**. TP problem giữ11, FP9 →11. Một số reference problem như
P000268/P002273 còn thiên về topic/task, cần chốt policy; không coi mọi missing
problem là limitation bị bỏ sai. Các limitation có nguồn rõ vẫn chưa phục hồi đủ.

## Hồi quy đã tái hiện: khóa cả facet thiếu nhưng không bị validator báo lỗi

**P002586 là ca ưu tiên cao nhất.** Draft method=[] được coi là hợp lệ nên
review scope chỉ gồm problem/dataset. Raw review2 thực tế đã sinh:

- `semi-supervised training` và `speaker adaptation` ở method;
- finding có đủ **Tamil** và **when significantly more test data than training
  data is available** ở contribution.

`assess_generation(raw_review2)` không có lỗi, score **100**. Nhưng
`assess_attempt(..., previous=draft)` khôi phục method=[] và contribution
thiếu điều kiện từ draft; score **88**, vẫn **validation_passed=true**.
Đã gọi trực tiếp hai hàm với paper/raw thật để tái hiện, không gọi model.

So với v3.5, mất hai method là hồi quy mới. Finding thiếu Tamil/điều kiện đã
có ở v3.5; v3.6 nay bỏ qua chính bản sửa mà review vừa tạo ra. Đây là bằng
chứng trực tiếp của tradeoff đã ghi trước push: validator không kiểm completeness
hoặc qualifier đầy đủ, nên khóa facet theo validation có thể giữ lỗi nghĩa.

Toàn run có137 lần giữ facet ngoài scope (method62, task36, contribution39);
8 thay đổi raw bị bỏ qua ở5 bài. Không phải cả8 đều là sửa ngữ nghĩa tốt:
có thay evidence ID/cách viết. P002586 là ca xác định được mất hai method và
bỏ một bản sửa qualifier. Không quy toàn bộ −8 TP method cho cơ chế này.

Các mất TP method còn ở P000681(−1), P001181(−1), P001963(−2), P003565(−1),
P004047(−1). Ví dụ P001963 chỉ giữ TTR-LDA-Community, mất LDA/Girvan-Newman;
P004047 chỉ giữ Morfessor. Nhiều method rỗng/thiếu vẫn qua kiểm tra bám chữ:
P000781, P002273, P003187, P003809. Bảo toàn draft trong cùng run không bảo
đảm chất lượng ngang output đã chọn của version trước.

## Các lỗi nghĩa bị điểm embedding che

- **P002586:** contribution thiếu Tamil/điều kiện vẫn được TP, cosine **0,93947**.
  Điểm không phản ánh bản sửa qualifier bị bỏ qua.
- **P001806:** chỉ có finding few-shot vẫn ghép với reference gồm cả zero-shot,
  cosine **0,97708**. Finding competitive zero-shot thực tế vẫn thiếu.
- **P002877:** cặp mô tả zero-shot/review classification có cosine **0,88613**
  nhưng bị negation_mismatch vì silver có without using pivot translation;
  hai finding không đối lập về kết quả. Đây là hạn chế matcher đã có.
- P001903 gộp event/relation extraction và multi-head attentions/convolutions;
  P002380 vẫn có array parameter/modularization trong một nhãn dài. FN không
  đồng nghĩa nội dung hoàn toàn mất; còn vấn đề granularity/ghép một–một.
- P003441 có9 contribution gồm cả chi tiết thiết kế/procedure; P002173 lặp
  alias MCTS và đưa goal tạo ghost team vào contribution. Có căn cứ từ nguồn
  nhưng vẫn cần rà vai trò, mức chắc chắn và đơn vị nhãn.

Không chỉnh matcher/reference/ngưỡng trong lần so này. **53,85% là embedding
agreement với reference AI trên cohort phát triển**, không phải human-confirmed
semantic accuracy và không đủ để suy rộng chất lượng 4.210 bài.

## Ưu tiên lần sửa tiếp

1. Cho phép review bổ sung facet rỗng/thiếu hoặc sửa qualifier có căn cứ, đồng
   thời bảo toàn item đúng thay vì khóa toàn facet theo việc không có lỗi lexical.
   Khóa ca P002586 bằng regression test trước khi thay scope.
2. Giữ phần phục hồi dataset; sửa riêng tách named resource và false acceptance
   Dota/UCI. Phân biệt lỗi source word/order với việc resource sai vai trò.
3. Kiểm completeness artifact, negative finding và method độc lập; phục hồi
   P004047, JTV/TARN/MCMM, LDA/Girvan-Newman. Tăng retry đơn thuần chưa đủ.
4. Xử lý phạm vi phủ định và cặp matcher sai trong phép đánh giá riêng có quyết
   định equivalent/partial; sau đó chốt reference và kiểm cohort mới.

Lượt này chỉ tải, kiểm, chấm và ghi báo cáo; chưa sửa generator/prompt/reference/
matcher hoặc push kernel mới. Không chạy lại165 test trước push vì không đổi
code production; đã replay output thực, tái hiện ca scope và kiểm counts/hash.

## Bằng chứng và tái lập

- [Report evaluator](../../../data/exp_a/evaluation/pilot50_v3_6_ai_v1/report.md),
  summary/manifest/per_paper cùng thư mục.
- [Counts, delta và retry/scope diagnostics](../../../data/exp_a/evaluation/pilot50_v3_6_ai_v1/error_analysis.json).
- [Nguồn, selected labels, v3.5 và audit tóm tắt của50 bài](../../../data/exp_a/evaluation/pilot50_v3_6_ai_v1/review_cases.jsonl).
- [Xác minh hoàn tất/hash/raw replay](../../../data/exp_a/.kaggle/review/pilot50_v3_6_completion_verification.json).
- Raw/applied đầy đủ: `data/exp_a/generated_v3_6_pilot50/annotation_metadata.jsonl`.
- Script phân tích tạm được giữ rõ tên: `tmp/pilot36_review.py`.

```powershell
.\.venv-qwen\Scripts\python.exe -X utf8 -B scripts/exp_a/evaluate_exp_a.py --source data/exp_a/generated_v3_6_pilot50 --gold data/exp_a/pilot50/ai_reference_v1/review_annotations.jsonl --expected-count 50 --threshold 0.85 --output data/exp_a/evaluation/pilot50_v3_6_ai_v1
.\.venv-qwen\Scripts\python.exe -X utf8 -B tmp/pilot36_review.py
```
