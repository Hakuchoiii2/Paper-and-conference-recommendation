# Pilot50 Qwen v3.1 — kết quả thử nghiệm ngày 15/10/2026

Pilot mới lưu đủ **50/50 bài**. Trên cùng 50 ID và tham chiếu AI được tạo từ nguồn trước khi xem nhãn mới, embedding micro-F1 tăng từ **39,41% lên 50,41% (+11,00 điểm phần trăm)** so với silver cũ của corpus. Đây là mức đồng thuận với tham chiếu AI theo matcher hiện hành, chưa phải semantic F1 được người xác nhận.

**Bản được giữ sau thử v3.2:** v3.1 + bộ lọc dataset named resource đạt **51,89%**.
Output gốc và reference giữ nguyên; bản dẫn xuất và rà lỗi còn lại nằm ở cuối báo cáo.

## Dữ liệu và cách chấm

- Kernel `htnkhi/exp-a-qwen-v3-pilot50`, version 2, session `358522537`, prompt/guideline 3.1. Kaggle CLI xác nhận COMPLETE.
- CLI tải từng file gặp HTTP 502 và lưu cả HTML lỗi. Đã dừng lần tải đó và lấy ZIP qua endpoint chính thức `DownloadKernelOutputZip` của Kaggle SDK đi kèm CLI. ZIP 3.063.049 byte, 72 member, kiểm tra CRC và đường dẫn giải nén đạt.
- Output duy nhất đang dùng nằm tại `data/exp_a/generated_v3_1_pilot50/`. Sau khi đối chiếu checksum, đã xóa gói ZIP, bản giải nén trùng và thư mục tải lỗi 502. Summary, xác minh tải và metadata kernel được gộp tại `data/exp_a/.kaggle/review/pilot50_v3_1_verification.json`.
- Tại thời điểm đánh giá v3.1, SHA-256 code generator, module v3, config, hai prompt/guideline và corpus của output remote khớp local. `load_silver(..., complete=True)` kiểm tra manifest, provenance, checksum, schema và đúng tập 50 ID. Các nâng cấp sau đó phải replay bằng policy 3.1 và fingerprint tương thích đã biết.
- Cohort ngẫu nhiên seed `20261014`, 50 trong 3.810 bài ngoài reference 400. Snapshot `pilot50/baseline_silver.jsonl` khớp silver cũ dùng chấm.
- Đã đọc title/abstract của cả 50 bài, viết tham chiếu AI source-only, chốt lúc **10:50:38 UTC+7**, trước khi mở dự đoán của pilot mới. Tham chiếu có 402 concept: problem 31, task 84, method 144, dataset 16, contribution 127.
- Tham chiếu: `data/exp_a/pilot50/ai_reference_v1/`. Đây là một lượt đọc và gán nhãn bởi Codex; không có lượt người xác nhận hoặc người gán nhãn thứ hai. Toàn bộ nguồn được lưu ở `source_papers.jsonl`; chưa có sổ adjudication độc lập cho từng concept. SHA-256 `review_annotations.jsonl`: `86554c401c72b7ee692c8a3dc00ead4677c8b9647c2ef4e353fcd647a1837be8`.
- Giữ nguyên evaluator, Qwen3-Embedding-0.6B local, revision đã pin, cosine **0.85**, exact/canonical/guarded embedding, ghép một–một trong cùng paper/facet. Không sửa reference hoặc ngưỡng sau khi xem điểm.

## So với silver cũ trên cùng 50 bài

| Chỉ số | Silver cũ | Pilot v3.1 | Chênh lệch điểm % |
|---|---:|---:|---:|
| Micro precision | 48,72% | 55,72% | +7,00 |
| Micro recall | 33,08% | 46,02% | +12,94 |
| Micro F1 | 39,41% | 50,41% | +11,00 |
| Macro F1 giữa năm facet | 36,23% | 48,72% | +12,49 |
| Exact lexical micro-F1 | 11,85% | 15,80% | +3,95 |

| Facet | F1 cũ | F1 mới | Chênh lệch điểm % |
|---|---:|---:|---:|
| problem | 19,61% | 38,60% | +18,99 |
| task | 32,86% | 52,55% | +19,70 |
| method | 50,00% | 51,82% | +1,82 |
| dataset | 42,42% | 50,00% | +7,58 |
| contribution | 36,28% | 50,62% | +14,34 |

TP tăng **133 → 185**, FP tăng **140 → 147**, FN giảm **269 → 217**. Bản mới có 332 nhãn, bản cũ 273 nhãn; tăng recall đi cùng tăng số nhãn. Theo F1 từng bài: 31 tăng, 13 giảm, 5 bằng nhau; 1 bài boilerplate có hai phía cùng rỗng nên F1 không xác định. Bài rỗng không được cộng thành một lượt đạt 100%.

Đây là đối chiếu với **silver cũ của corpus**, không phải lấy 39,41% làm điểm của Kaggle v3.0. Run Kaggle v3.0 chỉ lưu được 5 bài; chưa tính một F1 toàn 50 bài cho run thiếu 45 bài đó.

## Tính hoàn tất và cờ kiểm tra

| Thuộc tính | Kaggle v3.0 | Kaggle v3.1 |
|---|---:|---:|
| Bài được lưu | 5/50 | 50/50 |
| Missing/failed | 45 | 0 |
| Bài qua validation và có review hợp lệ | 5 | 26 |
| Best available fallback có cờ | Không lưu các bài không đạt | 24 |
| Audit từng bài còn giữ | 6 | 50 |
| Thời gian inference theo summary | 2.661,79 giây | 3.318,85 giây |

Count=50 gồm cả 24 fallback, không có nghĩa 50 bài qua validator. Bản mới giữ 129 lần sinh: 21 bài dùng hai lượt, 29 bài dùng ba lượt. Metadata cuối có 48 lỗi về thứ tự/từ nguồn hoặc paraphrase, 1 lỗi guard phủ định và 24 thông báo chưa có self-review hợp lệ. Các lỗi validator là chỉ báo kiểm tra cần đọc lại, không tự chứng minh sai ngữ nghĩa.

Sau dọn, 50 audit và 129 raw responses vẫn nằm đầy đủ trong `annotation_metadata.jsonl`. Các JSON trong `attempt_audits/` và `last_failure.json` đã được đối chiếu từng trường với metadata rồi xóa vì hoàn toàn trùng; checkpoint SQLite được giữ để resume.

Nhóm 26 bài qua validation có F1 54,39%; nhóm 24 fallback có F1 46,94%. Hai nhóm là tập khác nhau, không dùng chênh lệch này để khẳng định validator gây ra chất lượng cao hơn. Source-quality detector gắn cờ hai bài: boilerplate `P003491` và vỡ từ `P004047`; việc không có cờ chưa xác nhận nguồn sạch.

## Đọc đối chiếu và điểm còn yếu

- **Giữ qualifier tốt hơn:** `P001407` hiện giữ đủ “promising, although only partially successful”. Silver cũ chỉ giữ “union of these two corpus-based methods”. Matcher vẫn cho bản cũ TP ở đây, cho thấy F1 không đo hết việc giữ caveat.
- **Nguồn không phải abstract nghiên cứu:** `P003491` là lời quảng cáo tải sách; bản mới để cả năm facet rỗng và gắn `suspected_non_research`. Silver cũ cũng rỗng, nên cải thiện ở khả năng ghi cờ nguồn, không phải thêm TP.
- **Dataset còn quá rộng:** precision dataset giảm **41,18% → 36,11%**, dù recall tăng **43,75% → 81,25%**. Có 23 nhãn extra theo chính sách named resource: `Assamese`, `Bengali`, `Lao`, `Haitian`, `Zulu`, `Tamil` là ngôn ngữ; `100 discussion topics`, `annotated Arabic corpus`, `synthetic data` là mô tả chung. Các tên nền tảng/resource chưa rõ như Delicious/UCI cần người chốt chính sách trước khi gọi tất cả extra là lỗi thực.
- **Method bị gộp nhãn:** `P000669` gộp CRF, morphosyntactic features và semantic roles features thành một nhãn dài. Reference tách ba ý; matcher một–một hiện không ghép được nhãn dài này. Điểm bài giảm từ 71,43% xuống 54,55% nhưng đây không đủ để kết luận ba phương pháp đã bị mất ngữ nghĩa. Granularity là giới hạn thực của phép chấm.
- **Vẫn thiếu kết quả âm:** `P004047` chỉ giữ lợi ích morph-based SMT và bỏ finding “did not obtain higher BLEU scores”. Nguồn bị vỡ từ; bản mới có cờ fallback và suspected_text_corruption, nhưng cờ không sửa được nhãn bỏ sót. Matcher còn bỏ lỡ một số paraphrase đúng của bài này ở ngưỡng 0.85.
- **Validator có false alarm tiềm năng:** `P001181` bị báo mất phủ định khi nhãn giữ finding “self-training without reranking is surprisingly effective for parser domain adaptation”. Phủ định trong câu nguồn nói về accuracy **in-domain**, còn finding nói về **domain adaptation**. Cần xem phạm vi phủ định trước khi coi đây là nhãn sai.

Ưu tiên tiếp theo: chốt chính sách dataset theo named resource; thống nhất mức tách/gộp concept ở method; rà các finding âm và qualifier; sau đó xác nhận reference/matched pairs bằng người. Chưa có căn cứ từ lượt thử này để quyết định chạy lại toàn corpus.

## Rà sâu các chỗ còn hở và nguyên nhân

Đã đọc bản chọn cuối của cả 50 bài, đối chiếu nguồn và các trường hợp lỗi với raw attempts; tái hiện ba lỗi bằng kiểm tra trên output thật. Đây là chẩn đoán, chưa sửa thuật toán/prompt hoặc sửa nhãn để nâng điểm.

| Ưu tiên | Chỗ hở | Bằng chứng và nguyên nhân |
|---|---|---|
| 1 | Điểm chọn fallback thưởng việc lấp facet | `assess_generation` dành 60 điểm cho số facet có nhãn qua kiểm tra chữ. Với output thật `P000268`, giữ dataset chung “100 discussion topics spanning over 10 Twitter events” đạt **100**, xóa dataset không có proper name còn **88**; cả hai không có lỗi validator. Điểm bám chữ vì thế có thể ưu tiên nhãn sai vai trò. |
| 1 | Chọn bản ít thông tin hơn sau self-review | `P002380` chọn draft **54,00**, contribution chỉ còn “useful extensions and generalizations of Pascal”. Review 2/3 bổ sung **solution to the array parameter problem** và **modularization facility**, nhưng điểm **53,64** nên không được chọn. Các điều kiện chọn này là heuristic; có review chưa bảo đảm kết quả cuối đầy đủ hơn. |
| 1 | Bỏ kết quả âm và điều kiện áp dụng | `P004047` bỏ finding không tăng BLEU ở cả ba lượt. `P002586` giữ “achieved significant additional improvements in STT and KWS” nhưng bỏ **Tamil** và điều kiện có nhiều test data hơn training data. Validator chỉ thấy chữ trong span; không kiểm tra finding bị bỏ khỏi toàn nguồn hoặc điều kiện đứng trước span. |
| 1 | Dataset chưa được bảo vệ đúng định nghĩa | **23 extra trên 15 bài**, trong đó **6 bài vẫn qua validation**. Regex chỉ chặn vài dạng “dataset of …” và một số sample counts; vẫn nhận tên ngôn ngữ, “Dutch test collection”, “annotated Arabic corpus”, “alignment test cases”. Prompt đã yêu cầu named resource; lỗi còn ở việc Qwen không tuân thủ và validator không kiểm tra được vai trò resource. |
| 2 | Nhầm hoặc bỏ facet | `P001589` đưa **annotated Arabic corpus** vào method; `P001604` đưa mục tiêu **automatic estimation of accuracy loss** vào method. `P001431` để task/method rỗng dù nguồn mô tả phân loại online communities và synthesis of literature; `P003187` bỏ survey ở method nhưng lấy survey 250 managers làm dataset. |
| 2 | Mất trạng thái câu hỏi hoặc lấy background làm việc hiện tại | `P003673` problem biến “investigate **whether** … learns syntactic information” thành khẳng định “… learns syntactic information”. `P002273` method giữ simple functional-load measure từ đoạn được tác giả đánh dấu **previous work**. Chữ có mặt trong nguồn không đủ để xác nhận vai trò và trạng thái claim. |
| 2 | Contribution thiếu artifact được giới thiệu | `P001389` có JTV ở method nhưng contribution chỉ giữ finding về hiệu quả; `P001806` tương tự với TARN; `P001506` tương tự với SIVAE. Cần rà riêng artifact mới và finding, thay vì chỉ tìm câu kết quả. |
| 2 | Source quality chưa bắt đủ | `P001211` có “bri le”, “a acks”, nhưng `no_flag_detected`; `P003614` kết thúc giữa câu mà cũng không có cờ. Detector hiện chỉ tìm boilerplate và lỗi nối hai mảnh thành đúng một từ do validator đã phát hiện; không phải kiểm định đầy đủ nguồn. |
| 2 | Matcher và reference vẫn làm lệch điểm | `P000669` một nhãn method gộp ba kỹ thuật bị ghép một–một phạt thiếu; finding số liệu trong reference gộp hai kết quả cũng khiến nhãn tách đúng bị numeric guard loại. `P001407` nhãn cũ thiếu caveat vẫn được cosine ghép. Không thể xem mọi extra/missing là lỗi Qwen hoặc mọi TP là tương đương ngữ nghĩa. |

`P001181` còn minh họa false alarm của guard phủ định: câu nguồn chứa một vế nói self-training không cải thiện **in-domain** và một vế khẳng định hiệu quả với **domain adaptation**. Phép tìm subsequence lấy span qua cả hai vế rồi đòi nhãn giữ mọi từ phủ định; không phân biệt phạm vi phủ định. Một nhãn ngắn bỏ chủ thể, chỉ giữ “it is …”, lại dễ qua kiểm tra hơn dù kém rõ nghĩa.

Thứ tự xử lý đề xuất: **chọn fallback/coverage → named dataset và finding có điều kiện → đúng facet/artifact → matcher và xác nhận reference**. Các số hiện tại vẫn giữ nguyên để làm mốc; chưa sửa gold, hạ ngưỡng hoặc chạy lại inference trong lượt rà này.

## Dọn artifact

Đã xóa **179 file, 13,13 MiB**: bản tải lỗi, ZIP và code/output giải nén trùng, bản backup trước v3.1, source kernel trùng gói build, script/JSON/log tạm, draft reference trùng nhãn cuối, audit từng bài trùng metadata, và lượt exact 400 cũ không còn dùng có cùng silver/gold với `embedding_400`.

Giữ một output pilot có checkpoint và toàn bộ raw attempts trong metadata; một reference đã chốt kèm nguồn; hai kết quả chấm cũ/mới và một `comparison.json` chứa cả delta từng bài. Reference labels, input corpus và các điểm F1 không đổi. Code runtime/evaluator và các test đang dùng được giữ. `.kaggle/.gitignore` đã chặn mọi thư mục `downloads*` để lần tải sau không kéo bản sao vào danh sách source Git.

## Artifact và tái lập

Đã kiểm tra lại checksum của artifact, cùng 50 ID/reference/evaluator/model và cộng lại toàn bộ TP/FP/FN từ matched pairs. Sau dọn, **38 kiểm tra qua** (19 evaluator, 9 pipeline, 10 best-attempt v3); validate lại đủ 50 annotation và replay 129 raw generations từ metadata. Test chạy với thư mục tạm trong workspace vì thư mục temp mặc định của Windows sandbox bị từ chối quyền ghi; thư mục tạm đã được xóa sau kiểm tra.

- [Bản cũ: report](../../../data/exp_a/evaluation/pilot50_baseline_ai_v1/report.md), `summary.json`, `per_paper.jsonl`, `manifest.json` cùng thư mục.
- [Bản mới: report](../../../data/exp_a/evaluation/pilot50_v3_1_ai_v1/report.md), `summary.json`, `per_paper.jsonl`, `manifest.json` cùng thư mục.
- [So sánh máy đọc](../../../data/exp_a/evaluation/pilot50_comparison_ai_v1/comparison.json), gồm delta từng bài và hash hai manifest đầu vào.
- [Tham chiếu AI](../../../data/exp_a/pilot50/ai_reference_v1/review_annotations.jsonl), nguồn đầy đủ và manifest cùng thư mục.
- [Xác minh output remote và summary run](../../../data/exp_a/.kaggle/review/pilot50_v3_1_verification.json).

```powershell
.\.venv-qwen\Scripts\python.exe -B scripts/exp_a/evaluate_exp_a.py --source data/exp_a/generated --gold data/exp_a/pilot50/ai_reference_v1/review_annotations.jsonl --expected-count 50 --threshold 0.85 --output data/exp_a/evaluation/pilot50_baseline_ai_v1
.\.venv-qwen\Scripts\python.exe -B scripts/exp_a/evaluate_exp_a.py --source data/exp_a/generated_v3_1_pilot50 --gold data/exp_a/pilot50/ai_reference_v1/review_annotations.jsonl --expected-count 50 --threshold 0.85 --output data/exp_a/evaluation/pilot50_v3_1_ai_v1
```

Giới hạn: AI reference chỉ một lượt, chưa có người xác nhận; nhãn gộp/tách và ngưỡng embedding có thể làm sai TP/FP/FN. Không xem 50,41% là accuracy thật, không so trực tiếp với F1 trên cohort 400 bài, và không suy rộng cho 4.210 bài.

## Bản được giữ và các lỗi còn lại

Sau phép thử 28 phương án offline, đã giữ **prompt/guideline/scoring/ranking
v3.1 + named-resource dataset filter v3.2**. Không lấy prompt/scoring/ranking
v3.2, không ghép contribution mới vì lợi ích chỉ khoảng 0,06 điểm %.

- Output riêng: `data/exp_a/generated_v3_1_filtered_pilot50/`.
- Config lúc giữ mốc đối chứng bật `dataset_resource_filter=true`; engine 3.3 chỉ lọc dataset
  sau khi chọn attempt theo v3.1. Mỗi item bị bỏ có index, concept, source,
  evidence và reason trong `postprocessing`; replay đối chiếu được với raw.
- Có đủ 50 bài, giữ nguyên 129 raw responses, selected attempt, điểm raw,
  fallback và mọi nhãn ở bốn facet khác. Không gọi generator/Qwen hoặc push Kaggle.
- Chấm lại qua [evaluator hiện hành](../../../data/exp_a/evaluation/pilot50_v3_1_filtered_ai_v1/report.md):
  TP 185, FP 126, FN 217; precision **59,49%**, recall **46,02%**, F1 **51,89%**.
  Bộ lọc bỏ 21 FP theo matcher, không mất TP. Source vẫn là silver, còn 24 cờ
  fallback; việc lọc không biến raw chưa hợp lệ thành đã qua review.
- Source cũ v3.1/v3.2, reference và evaluator giữ nguyên. Các bản đã self-review
  không tự được đưa đi sinh lại chỉ vì tăng engine version. Checkpoint/JSONL
  resume kiểm tra protocol và filter config trước khi tin metadata.
- 144 test qua (87 project, 57 exp_A); review độc lập đã kiểm tra lại các đường
  resume và audit. Build local có 13 member hợp lệ (10 source/config + 3 export
  dùng resume), không có reference/credential. Thư mục test tạm được dọn.

### Phần cần ưu tiên tiếp theo

Thống kê dưới đây là **FN/FP theo matcher trên toàn pilot**, chưa phải số lỗi
ngữ nghĩa đã xác nhận. Đã đọc lại nguồn và nhãn của 17 bài được chọn theo các
kiểu lỗi tiêu biểu; đây không phải một mẫu ngẫu nhiên để ước lượng tần suất lỗi.

| Facet sau filter | FN | FP | Bài có FN |
|---|---:|---:|---:|
| Method | 80 | 39 | 41 |
| Contribution | 66 | 53 | 39 |
| Task | 48 | 17 | 37 |
| Problem | 20 | 15 | 19 |
| Dataset | 3 | 2 | 3 |

Method, contribution và task chiếm 194/217 (89,4%) missing labels. Bộ lọc dataset
đã cải thiện precision; nút thắt lớn còn lại là coverage và mức tách concept.

| Ưu tiên | Lỗi nguồn/nhãn đã đọc | Hướng giải quyết |
|---|---|---|
| 1 — Method | `P000669` có CRF, morphosyntactic features, semantic roles features trong một nhãn; `P000268` gộp unigram/bigram/LDA. Đây là thông tin có mặt nhưng bị gộp. `P001211` thực sự thiếu các thao tác tấn công insert typos/change word boundaries/add innocuous words; `P002380` thiếu hai nguyên tắc được nêu riêng. | Tách các kỹ thuật độc lập thành cụm ngắn có span rõ, tái dùng cùng evidence ID khi cần. Phân biệt tách nhãn gộp với bổ sung kỹ thuật chưa được trích; tránh chia tùy tiện tên riêng hoặc một kỹ thuật thành parent/child trùng nhau. |
| 1 — Contribution | `P001506`, `P001806` giữ findings nhưng quên artifact mới SIVAE/TARN. `P004047` bỏ kết quả không tăng BLEU; `P001211` bỏ finding adversarial training không khắc phục hoàn toàn tấn công. `P002380` bỏ array parameter solution/modularization facility dù review đã từng sinh chúng. | Rà riêng ba nhóm artifact mới, finding dương và finding âm/null. Trước khi gọi model thêm, tìm lại nhãn có nguồn trong các review đã lưu; chỉ hợp nhất phần bổ sung được kiểm tra, không union mọi attempt. |
| 2 — Task | `P001506` dùng thủ tục tích hợp syntactic trees thay task, bỏ text generation/controlled generation/unsupervised paraphrasing. `P001806` chỉ ghi action recognition và mất few-shot/zero-shot. `P001431` để task rỗng dù nguồn nêu mục đích examine classification schema. | Lấy mục tiêu thao tác từ title và các câu nêu mục đích, giữ đối tượng và setting phân biệt task. Tách mục tiêu độc lập; không dùng câu mô tả cách làm thay mục tiêu. Rà theo facet để tránh làm mọi nhãn thành câu dài như v3.2. |
| 2 — Problem | `P001211` lấy câu nền “pressing problem”, bỏ giới hạn cùng kiểu dữ liệu và độ mong manh trước tấn công. `P001431` bỏ hạn chế no standard definition. Ngược lại, `P001806` đưa tên task vào problem. | Chỉ nhận limitation/question cụ thể đang được giải quyết; giữ trạng thái whether nếu nguồn có, không tự thêm câu hỏi và không ép facet có nhãn. |
| 2 — Chất lượng nguồn | `P001211` có bri le/a acks; `P004047` có nhiều từ tách; `P003614` bị cụt giữa câu; `P003491` là quảng cáo tải sách. | Ưu tiên lấy lại nguồn đúng hoặc quarantine bài không phải nghiên cứu. Nếu chuẩn hóa OCR, giữ raw và ánh xạ span; không sửa âm thầm để raw evidence trông như khớp. Không kỳ vọng prompt chữa được corpus thiếu/hỏng. |
| 3 — Chuẩn nhãn và phép chấm | `P001409` đã giữ đúng 75,60%/70,65% nhưng nhãn kéo cả các kết quả của hệ đối thủ nên chưa ghép được. `P000268` nêu vấn đề LDA chưa được kiểm chứng có cơ sở trong nguồn, nhưng reference chỉ có một problem rộng khác. | Thống nhất đơn vị concept giữa extraction/reference, tách findings độc lập và giữ đúng metric/setting/so sánh cần thiết. Rà các cặp bất đồng và reference bằng người; giữ reference/ngưỡng hiện tại làm mốc, không hạ ngưỡng để chữa điểm. |

### Dataset còn sót: cần phân biệt lỗi extraction và reference

- `P002877` bỏ **Yelp reviews** dù nguồn nói rõ dùng reviews để phân loại: một
  thiếu sót extraction đáng sửa.
- Hai missing khác là **WSJ Penn Treebank** (`P001181`, trong vế mô tả kết quả
  prior work) và **MUC7 newspaper corpus** (`P001484`, corpus cha của MUC7 T).
  Cần người xác nhận quy tắc used-vs-mentioned và parent/extension trước khi
  ép model bổ sung cả hai.
- Hai extra còn lại là mô tả brain data có DOTA 1 (`P003211`) và dữ liệu từ UCI
  repository (`P003308`). Bộ lọc hiện hành chưa loại chúng; acronym/tên game/
  repository không tự chứng minh có một dataset được đặt tên. Không mở rộng
  thành lọc bỏ mọi lỗi lexical: phép thử đó đã làm mất TP và giảm F1.

Thứ tự đề xuất hiện tại: **tách/recover method → artifact và finding âm ở
contribution → task đủ setting → problem đúng vai trò**, song song sửa nguồn
và adjudicate các bất đồng reference. Đây là các hướng sửa được xác định từ
nguồn; chưa có số F1 dự đoán cho từng hướng nếu chưa áp dụng và đo.
