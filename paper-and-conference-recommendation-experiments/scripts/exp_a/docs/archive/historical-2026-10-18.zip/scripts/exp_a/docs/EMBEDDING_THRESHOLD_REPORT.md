# Thử ngưỡng embedding Exp A — 2026-10-14

**Báo cáo probe trước khi tích hợp; điểm mock dưới đây không phải điểm trên 400 bài.**

Model: `Qwen/Qwen3-Embedding-0.6B`, revision `97b0c614be4d77ee51c0cef4e5f07c00f9eb65b3`, last-token + L2, float32, cuda.
Qwen Embedding chuyên tạo vector, chạy local sau khi tải. Không gọi API/LLM làm giám khảo.
Dùng cùng cách mã hóa cho hai phía, không thêm instruction tìm kiếm; similarity đối xứng.
Lấy token cuối không phải padding theo model card; ngưỡng được chọn lại cho encoder này.

## Mẫu và cách chọn

48 cặp mock thuộc 24 tình huống, cân bằng cùng nghĩa/khác nghĩa theo thiết kế.
32 cặp để chọn ngưỡng; 16 cặp kiểm tra, tách theo tình huống để hai biến thể của cùng câu không lọt sang hai tập.
Đáp án mock do Codex soạn trước khi tính similarity, chưa được người xác nhận độc lập.
Có viết tắt, diễn đạt lại và các cặp khó: phủ định, số liệu, điều kiện, phạm vi, tên dataset/model.
Thêm 12 bài thực được chọn có chủ đích (201 cặp), chỉ minh họa ghép nhãn.
Các bài thực thuộc cohort đang có; không coi chúng là tập test độc lập cho việc chọn ngưỡng.
Giữ nguyên mock/split của lượt encoder trước. Tập check đã được xem ở lượt trước nên so model vẫn mang tính thăm dò.

## Kết quả phân loại cặp mock

| Ngưỡng | P chọn ngưỡng | R chọn ngưỡng | F1 chọn ngưỡng | P kiểm tra | R kiểm tra | F1 kiểm tra | FP kiểm tra |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 0.50 | 50.0% | 100.0% | 66.7% | 50.0% | 100.0% | 66.7% | 8 |
| 0.55 | 50.0% | 100.0% | 66.7% | 50.0% | 100.0% | 66.7% | 8 |
| 0.60 | 50.0% | 100.0% | 66.7% | 50.0% | 100.0% | 66.7% | 8 |
| 0.65 | 50.0% | 100.0% | 66.7% | 50.0% | 100.0% | 66.7% | 8 |
| 0.70 | 50.0% | 100.0% | 66.7% | 57.1% | 100.0% | 72.7% | 6 |
| 0.75 | 50.0% | 100.0% | 66.7% | 66.7% | 100.0% | 80.0% | 4 |
| 0.80 | 51.6% | 100.0% | 68.1% | 72.7% | 100.0% | 84.2% | 3 |
| 0.85 | 60.9% | 87.5% | 71.8% | 70.0% | 87.5% | 77.8% | 3 |
| 0.90 | 73.3% | 68.8% | 71.0% | 80.0% | 50.0% | 61.5% | 1 |
| 0.95 | 80.0% | 25.0% | 38.1% | 100.0% | 12.5% | 22.2% | 0 |
| 0.98 | 100.0% | 6.2% | 11.8% | 0.0% | 0.0% | 0.0% | 0 |
| 0.99 | 100.0% | 6.2% | 11.8% | 0.0% | 0.0% | 0.0% | 0 |

Ngưỡng được quy tắc chọn trên 32 cặp calibration: **0.85**.
Quy tắc: F1 cao nhất; nếu hòa, ưu tiên precision rồi ngưỡng cao hơn. Không dùng tập kiểm tra để chọn.
**F1 trong bảng là F1 phân loại cặp mock, không phải F1 trích facet của Qwen.**

## So với encoder trước trên cùng bộ mẫu

| Encoder | Ngưỡng chọn từ calibration | F1 calibration | P check | R check | F1 check |
|---|---:|---:|---:|---:|---:|
| AITeamVN/Vietnamese_Embedding_v2 | 0.85 | 71.0% | 71.4% | 62.5% | 66.7% |
| Qwen/Qwen3-Embedding-0.6B | 0.85 | 71.8% | 70.0% | 87.5% | 77.8% |

Mỗi encoder tự chọn ngưỡng từ cùng 32 cặp calibration. Không so model bằng cùng một ngưỡng tùy ý.

## Những cặp mock vẫn chấm sai tại ngưỡng được chọn

| Tập | Nhãn A | Nhãn B | Cosine | Đáp án theo thiết kế | Lý do |
|---|---|---|---:|---|---|
| calibration | uses a 16-bit architecture instead of a 32-bit architecture | uses a 32-bit architecture instead of a 16-bit architecture | 0.9510 | khác nghĩa | reversed comparison |
| calibration | achieves 90% accuracy | achieves 85% accuracy | 0.9457 | khác nghĩa | different number |
| calibration | improves performance with limited training data | improves performance with abundant training data | 0.9408 | khác nghĩa | different condition |
| check | RNNs fail when generalization requires systematic compositional skills | RNNs fail at every generalization task | 0.9157 | khác nghĩa | lost restriction |
| calibration | CIFAR-10 | CIFAR-100 image dataset | 0.9022 | khác nghĩa | different dataset identity |
| calibration | unsupervised learning | semi-supervised learning | 0.8937 | khác nghĩa | different supervision |
| calibration | English-to-German translation | translating German into English | 0.8836 | khác nghĩa | reversed direction |
| calibration | named entity recognition | named entity linking | 0.8832 | khác nghĩa | different task |
| check | support vector machines | support vector regression | 0.8819 | khác nghĩa | different prediction task |
| check | reduces word error rate by 0.5 percentage points | achieves a 0.5 percent relative reduction in word error rate | 0.8806 | khác nghĩa | absolute versus relative |
| calibration | sentiment classification | emotion classification | 0.8645 | khác nghĩa | different target |
| calibration | improves prediction accuracy | reduces prediction accuracy | 0.8606 | khác nghĩa | opposite direction |
| check | Cora dataset | the Cora benchmark | 0.8198 | cùng nghĩa | intended paraphrase |
| calibration | does not require labeled training data | works without labeled training examples | 0.8026 | cùng nghĩa | intended paraphrase |
| calibration | unsupervised learning | learning without labeled examples | 0.8006 | cùng nghĩa | intended paraphrase |

## Ví dụ nhãn thực

Điểm dưới đây chỉ cho thấy độ gần theo encoder. Không tự xác nhận tương đương hoặc lỗi của Qwen/gold.

| Bài / facet | Qwen | Reference | Cosine |
|---|---|---|---:|
| P000406 / task | train neural network language model | train a neural network language model | 0.9719 |
| P001274 / task | assess the degree to which CDSM capture semantic interactions | assessing the degree to which CDSM capture semantic interactions | 0.9938 |
| P000503 / method | 16- rather than 32-bit architecture | 16- rather than a 32-bit architecture | 0.9939 |
| P000474 / contribution | 90% of monolingual performance | combined resources produce about 90% of monolingual performance in retrieving Chinese documents | 0.7183 |
| P001366 / contribution | evidence of systematic racial bias | systematic racial bias in all datasets | 0.8516 |

## Tác động cơ học trên 12 bài minh họa

Chỉ ghép trong cùng paper/facet. Ghép một–một tối đa số cặp, rồi tối đa tổng similarity khi hòa.
Số match tăng không tự chứng minh extraction tốt hơn: ngưỡng thấp có thể công nhận cả cặp sai.

| Cách so | Ghép được | Qwen dư | Reference thiếu | F1 đồng thuận |
|---|---:|---:|---:|---:|
| Exact sau chuẩn hóa | 23 | 84 | 68 | 23.2% |
| Cosine ≥ 0.50 | 72 | 35 | 19 | 72.7% |
| Cosine ≥ 0.55 | 69 | 38 | 22 | 69.7% |
| Cosine ≥ 0.60 | 64 | 43 | 27 | 64.6% |
| Cosine ≥ 0.65 | 61 | 46 | 30 | 61.6% |
| Cosine ≥ 0.70 | 59 | 48 | 32 | 59.6% |
| Cosine ≥ 0.75 | 53 | 54 | 38 | 53.5% |
| Cosine ≥ 0.80 | 47 | 60 | 44 | 47.5% |
| Cosine ≥ 0.85 | 43 | 64 | 48 | 43.4% |
| Cosine ≥ 0.90 | 40 | 67 | 51 | 40.4% |
| Cosine ≥ 0.95 | 32 | 75 | 59 | 32.3% |
| Cosine ≥ 0.98 | 25 | 82 | 66 | 25.3% |
| Cosine ≥ 0.99 | 23 | 84 | 68 | 23.2% |

## Diễn giải và giới hạn

Đây là ngưỡng thăm dò cho encoder đang thử. Cần rà các false positive và false negative ở bảng trên trước khi quyết định dùng.
Nếu nhãn khác số liệu/phủ định/điều kiện vẫn có similarity cao, tăng ngưỡng sẽ đồng thời làm mất paraphrase đúng.
Chưa đủ căn cứ để thay evaluator chính hoặc báo semantic accuracy trên 400 bài.
Cần một tập cặp được người xác nhận, tách khỏi tập báo cáo cuối, để kiểm định ngưỡng chính thức.

Dữ liệu Qwen và scores: `../../data/exp_a/evaluation/embedding_probe/qwen3_0_6b/`.
Lượt encoder trước: `../../data/exp_a/evaluation/embedding_probe/vietnamese_embedding_v2/`.
Mẫu mock: `../../data/exp_a/samples/embedding_threshold_pairs.jsonl`.
Script probe ban đầu đã được gộp vào evaluator và bỏ để tránh lặp code.
Chạy đủ cohort từ gốc project bằng `.venv-qwen/Scripts/python.exe -B scripts/exp_a/evaluate_exp_a.py`.
Kết quả đầy đủ nằm ở `data/exp_a/evaluation/embedding_400/`; bảng trong tài liệu này là phép thử mock trước khi tích hợp.

Tham khảo: [Qwen Embedding model card](https://huggingface.co/Qwen/Qwen3-Embedding-0.6B), [Sentence Transformers STS](https://sbert.net/docs/sentence_transformer/usage/semantic_textual_similarity.html).
