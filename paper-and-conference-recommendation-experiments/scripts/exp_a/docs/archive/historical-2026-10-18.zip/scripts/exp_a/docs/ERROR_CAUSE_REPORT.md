# Vì sao Exp A có F1 thấp? — rà lỗi ngày 14/10/2026

**Nhãn Qwen hiện có là nhóm vấn đề lớn nhất trong mẫu rà, nhưng không chiếm toàn bộ nguyên nhân.** Ước lượng có trọng số: khoảng **43%** số nhãn bị tính dư/thiếu thuộc nhóm Qwen, **21%** do matcher bỏ lỡ cặp cùng nghĩa, **20%** do cách chia concept khác nhau, **13%** thuộc reference, và **3%** chưa rõ. Đây là nhận định sơ bộ của AI trên các lỗi đang bị evaluator tính, cần người duyệt độc lập xác nhận.

Đã đóng băng evaluator, ngưỡng **0.85**, reference và toàn bộ silver. Điểm hiện tại vẫn là **38.89% micro-F1**: TP 1298, FP 2055, FN 2024. Chỉ thêm báo cáo và dữ liệu rà lỗi; không sửa nhãn để làm điểm tăng.

**Cách lấy mẫu và ý nghĩa tỷ lệ**

Rà **100 error slots trên 86 bài**: 10 nhãn cho mỗi ô 5 facet × FP/FN. FP là nhãn Qwen không được ghép; FN là nhãn reference không được ghép. Chọn mẫu trước khi nhận định ngữ nghĩa, seed 20261016. Đã chạy lại phép lấy mẫu và thu đúng 100 nhãn.

Do số lỗi giữa các ô khác nhau, tỷ lệ ước lượng dùng trọng số N_ô/10 trên tổng **4079 FP+FN slots**. Ví dụ dataset_FN chỉ có 88 slots còn method_FN có 601. Vì vậy số mẫu thô và tỷ lệ có trọng số khác nhau.

| Nhóm nhận định chính | Số mẫu /100 | Ước lượng có trọng số |
|---|---:|---:|
| Nhãn Qwen thiếu/sai vai trò hoặc sai quy ước | 43 | 43.3% |
| Cùng nghĩa nhưng matcher bỏ lỡ | 22 | 21.5% |
| Khác cách gộp/tách hoặc mức chi tiết | 20 | 19.6% |
| Reference thiếu ý hoặc nhãn có vấn đề | 12 | 12.7% |
| Chưa đủ căn cứ phân loại | 3 | 3.0% |

Mỗi slot được gán một nhóm chính; một nhãn vẫn có thể có vấn đề phụ. Một lỗi ngữ nghĩa có thể gây cả FP lẫn FN, nên đây không phải 4079 lỗi độc lập, không phải tỷ lệ bài sai, và không phải số điểm F1 có thể thu hồi. Nhóm granularity được giữ riêng, tránh quy mọi bất đồng cho Qwen hoặc reference.

**Qwen đang vướng ở đâu**

Trong 43 slots xếp nhóm Qwen: **26** thiếu concept/claim hoặc thiếu vai trò được nguồn nêu rõ; **9** dùng collection không tên hoặc task làm dataset; **6** chọn thao tác/thủ tục báo cáo thay cho task; **2** giữ nhãn quá thiếu nội dung/điều kiện. Đây là số mẫu thô, không phải tỷ lệ toàn bộ corpus.

- **Task nhầm với cách thực hiện.** P003438 có task image classification ngay trong title, nhưng Qwen chỉ ghi select unlabeled examples for the user to label. Đây là bước active learning, chưa giữ bài toán phân loại ảnh. EA082/EA083 là hai slots của cùng một bất đồng.
- **Bỏ ý chính dù ý có nguồn.** P004067 giới thiệu optimization model; Qwen giữ ở method nhưng bỏ khỏi contribution. P003939 bỏ finding combined descriptor vượt single descriptor, chỉ giữ state-of-the-art chung. Matcher không thể tạo ra ý còn thiếu.
- **Dataset chưa tuân thủ quy ước tên tài nguyên.** P004103 đưa splog detection vào dataset dù nguồn gọi là task; nhiều mẫu khác chỉ ghi số lượng tweets/participants hoặc collection không có tên.

Validator hiện tại ở `data/exp_a/build_exp_a.py:202` kiểm tra schema, câu evidence có thật trong nguồn, độ giữ từ và trùng nhãn. Các bước này **chưa kiểm tra đúng facet, tên dataset hợp lệ hay trích đủ ý**. Do đó nhãn có evidence đúng vẫn có thể mang vai trò sai. Đây là giới hạn quan sát được của kiểm tra; chưa chứng minh một cấu hình model hoặc prompt cụ thể gây ra các lỗi.

Manifest merge ghi rõ provenance hiện tại dùng để validation handoff; original generator của part 3 chưa rõ. Vì vậy không suy từ config hiện tại rằng mọi nhãn đã được sinh bằng đúng prompt/model đó.

**Những lỗi không nên quy hết cho Qwen**

- **Matcher:** P003039: Qwen release the crosssentence annotations for MUC6; reference crosssentence annotations for MUC6. Cùng tài nguyên đóng góp, chỉ thêm động từ, nhưng vẫn không ghép (EA070).
- **Reference:** P002954: abstract và Qwen đều nêu LSTM language model performed poorly on many constructions; reference contribution bỏ finding này nên Qwen bị tính FP (EA068).
- **Đơn vị concept:** P003780: Qwen gộp Chi-square testing and Insignificant rule pruning; reference tách hai method. Quy tắc một-một không thể ghép một nhãn với hai nhãn (EA087). Nới cosine không giải quyết cách đếm này.

Trên cả 400 bài, nhãn Qwen có trung vị **7 từ** so với **3 từ** ở reference; **37.9%** nhãn Qwen dài hơn 8 từ, reference **7.1%**. Đây là dấu hiệu hai nguồn biểu diễn concept khác nhau, không phải bằng chứng mọi nhãn dài đều sai.

**Facet nào kéo điểm xuống**

| Facet | F1 | FP | FN | Tổng slots |
|---|---:|---:|---:|---:|
| contribution | 30.21% | 567 | 556 | 1123 |
| dataset | 49.73% | 288 | 88 | 376 |
| method | 46.79% | 386 | 601 | 987 |
| problem | 43.60% | 328 | 337 | 665 |
| task | 27.73% | 486 | 442 | 928 |

Task và contribution có F1 thấp nhất, đồng thời chiếm **50.3%** số FP+FN slots. Method cũng có nhiều nhãn reference chưa được ghép (601 FN); cần tách thiếu nội dung thật với khác phạm vi nhãn.

**Vì sao test cặp khoảng 83% mà 400 bài chỉ khoảng 39%**

82.93% là F1 phân loại trên 44 cặp nhãn được chọn để kiểm tra matcher. 38.89% là agreement của toàn bộ nhãn trích xuất trên 400 bài. Test cặp không đo ý Qwen bỏ sót, nhãn dư, sai facet, hay gộp một ý thành nhiều nhãn. Hai chỉ số trả lời hai câu hỏi khác nhau.

**Giới hạn và hướng xử lý**

Đây là AI audit, reference cũng do AI tạo; confidence high/medium là tự đánh giá, không phải xác suất đã được kiểm định. Có 37/43 mẫu nhóm Qwen được đánh giá high, nhưng chưa gọi chúng là kết luận human gold. Mỗi ô chỉ có 10 mẫu; không nên đọc số thập phân như độ chính xác thật.

400 bài đã dùng để phát triển matcher/reference và được chọn thiên về silver đầy đủ, ít lỗi validation. Kết quả rà chỉ mô tả tập phát triển này, chưa đại diện cho toàn bộ 4210 bài. Audit này chỉ rà FP/FN, chưa kiểm tra các TP có thể ghép nhầm; không cho phép tính một F1 đã “sửa đúng”.

Nên ưu tiên làm rõ cách chọn task/contribution và đơn vị concept, rồi thử thay đổi extraction trên một lô nhỏ với evaluator cố định và reference được người duyệt độc lập từ nguồn. Chưa có bằng chứng để hứa mức tăng F1, cũng chưa cần chạy lại hơn 4000 bài. Tiếp tục chỉnh matcher theo từng case của 400 bài sẽ làm khó đánh giá cải thiện thật.

Dữ liệu kiểm tra: `data/exp_a/evaluation/error_cause_audit/audit.jsonl` có 100 nhãn, nhãn hai bên, evidence nguyên văn, lý do và confidence. `summary.json` lưu trọng số, phương pháp replay mẫu, hash đầu vào và kết quả xác minh. Mọi quote đã khớp title/abstract gốc; mọi counterpart nhóm matcher còn khả dụng; hash evaluator/reference/silver/kết quả 400 bài giữ nguyên.
