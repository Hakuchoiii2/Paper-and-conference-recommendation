# Rà lỗi output pilot50 v3.4

Lỗi runtime merge đã sửa: version 6 COMPLETE, đủ 50 bài, giữ nguyên 130 raw
generations từ hai T4 của v5. Lượt này rà counts của toàn cohort, tất cả các
bất đồng problem/dataset và đọc sâu 15 ca với nguồn/raw attempts. Không sửa
nhãn, prompt, generator, matcher hay reference trong lượt rà.

## Điểm tổng và phần bị che bởi điểm tổng

Micro-F1 **52,57% → 53,82%** (+1,25 điểm %), precision **57,74% → 62,50%**,
recall **48,26% → 47,26%**. TP **194 → 190**, FP **142 → 114**, FN **208 → 212**.
Tổng số nhãn dự đoán giảm 336 → 304. Điểm tổng tăng nhờ giảm nhãn dư nhiều hơn
mức mất TP, chưa chứng minh mô hình lấy được đầy đủ nội dung hơn.

| Facet | F1 v3.3 | F1 v3.4 | TP / FP / FN v3.4 |
|---|---:|---:|---:|
| Problem | 26,23% | **14,63%** | 3 / 7 / 28 |
| Task | 53,06% | **60,56%** | 43 / 15 / 41 |
| Method | 57,38% | **61,54%** | 72 / 18 / 72 |
| Dataset | 80,00% | **53,85%** | 7 / 3 / 9 |
| Contribution | 50,78% | **49,43%** | 65 / 71 / 62 |

FP/FN ở đây là bất đồng theo matcher/reference AI. Một số là khác mức tách/gộp
hoặc khác policy; không coi toàn bộ là lỗi ngữ nghĩa đã adjudicate.

## 1. Problem bị bỏ quá nhiều, gồm limitation có thật

Problem chỉ còn **10 nhãn**, so với 30 ở v3.3 và 31 trong reference. **43/50
bài để problem=[]**; có 21 bài reference ghi problem nhưng dự đoán rỗng.
Không phải cả 43 list rỗng đều sai. Các ca bỏ limitation có căn cứ rõ gồm:

- **P000332:** nguồn nêu “threats to internal validity” do informal social spread
  of information; cả ba attempt đều không lấy problem.
- **P001484:** nguồn nói phép đếm token giả định chi phí đồng đều là
  “intrinsically inadequate”; review bỏ nhãn sai rồi để problem rỗng.
- **P001903:** nguồn nói cách chỉ phát hiện một entity pair trên short span
  “is not ideal” với câu biomedical dài; problem vẫn rỗng.
- **P003661:** normality assumption “is not strictly valid” cho performance
  measures; ba attempt không phục hồi limitation.
- **P002652:** nguồn phân biệt known NP-hard là background với new stronger
  result NP-hard even on trees. Giữ finding mới không thay thế được việc nhận
  diện limitation nền theo policy tham chiếu.

Quan sát phù hợp với việc model trở nên quá dè dặt ở problem. Prompt, review
và empty-output guard thay đổi trong cùng run; chưa có ablation tách tác động.
Reference cũng có problem thiên về topic/task, như P000268/P002273, cần người
chốt lại policy trước khi diễn giải tất cả missing là sai.

## 2. Ví dụ prompt bị chép vào draft

Câu **“existing rankers cannot handle unseen vocabulary”** được chép nguyên
từ ví dụ prompt vào draft của **P001484, P001806, P004047**. Nguồn của ba bài
không có câu đó và không cùng tình huống ranker/vocabulary trong ví dụ.

Đây là lỗi grounding có bằng chứng ở raw generation. **Không còn câu ví dụ này
trong selected output cuối**: review đã bỏ hoặc thay. Tuy vậy nó tiêu lượt
review và có ca thay câu sai bằng `[]` thay vì tìm limitation thật. Ví dụ đúng
về mặt hướng dẫn vẫn có thể bị model nhỏ dùng như nội dung cần trả lời.

## 3. Self-review mắc kẹt; thêm seed không tạo ra lần thử khác

**21/28 bài fallback** có hai raw responses liền nhau giống hệt. Với **14 bài**,
draft và review đầu giống nhau, lỗi validator cũng giống nhau: theo cách dựng
message hiện tại, request cho review 2 và review 3 không đổi. Cấu hình
`do_sample=false` khiến đổi seed không tạo thêm một phương án sampling.

- **P001431:** cả ba attempt trả năm facet rỗng. Guard gắn đúng fallback và
  coverage error; chưa phục hồi mục tiêu, literature synthesis hoặc schema.
- **P002877:** cả ba attempt giữ nguyên missing dataset WMT15/Yelp reviews.
- **P003661:** diagnostic plots được gán evidence A3 trong khi ý đó nằm ở A4;
  feedback có lỗi cụ thể nhưng cả ba response giữ nguyên.

Retry hiện chủ yếu yêu cầu trả lại full JSON với cùng phản hồi, chưa buộc model
đổi cách đọc nguồn hoặc sửa từng item/ID. Không có căn cứ chỉ tăng số lượt và
mong chất lượng cải thiện nếu request vẫn lặp.

## 4. Dataset giảm tập trung ở hai bài; filter cũng còn false acceptance

Năm TP dataset mất so với v3.3 nằm đúng ở hai bài:

- **P001903: mất 4 TP.** BioNLP 2009/2011/2013 và BioCreative 2017 được nêu
  ngay trong contribution của cả extract lẫn review, nhưng dataset luôn `[]`.
  Raw không sinh các dataset này nên **không phải filter xóa nhầm**.
- **P004047: mất 1 TP.** Europarl có trong câu nguồn, nhưng selected dataset là
  “three Nordic languages (Danish, Finnish, and Swedish)”. Đây là tên/ngữ cảnh
  ngôn ngữ, không phải resource; filter vẫn giữ.

Hai false acceptance khác còn tồn tại: P003211 giữ “brain data ... playing
Dota 1” vì có tên game; P003308 giữ “real world data from UCI repository” nhưng
không chỉ ra dataset cụ thể. Bảy item đã lọc được ghi đầy đủ trong metadata;
không có BioNLP, BioCreative hay Europarl trong danh sách bị lọc.
WSJ Penn Treebank và MUC7 newspaper corpus là các missing khác có yếu tố
background/nguồn dẫn xuất, cần policy nguồn nhất quán khi adjudicate.

## 5. Contribution vẫn thiếu artifact, bỏ finding âm và lẫn mô tả phương pháp

Contribution giữ 65 TP như v3.3 nhưng FP tăng **64 → 71**; FN còn 62.

- **P001389/P001806:** JTV/TARN có ở method nhưng không có artifact tương ứng
  trong contribution. P003308 tương tự với MCMM.
- **P004047:** finding “did not obtain higher BLEU scores” lại biến mất khỏi
  cả ba raw attempts. Câu thử nghiệm trên ba ngôn ngữ lại được đưa vào
  contribution. Không thể sửa bỏ sót này chỉ bằng chọn một attempt khác đã lưu.
- **P003441:** 9 contribution gồm cả chi tiết thiết kế/procedure như dùng
  UML/P, cách kết hợp skills. Một phần có căn cứ nhưng khác độ chi tiết với
  ba reference; không gọi tất cả extra là hallucination.

P004047 cũng cho thấy giới hạn của scoring: attempt 2 có thêm mô tả thử nghiệm
ở contribution đạt **78**, attempt 3 bỏ mô tả đó còn **64**, cùng hai lỗi lexical.
Ranking chọn attempt 2. Điểm bám chữ không xác nhận đúng vai trò/novelty hoặc
đầy đủ findings; cần đo riêng trước khi thay toàn bộ scoring như đã thử ở v3.2.

## 6. Tách lỗi validator/matcher khỏi lỗi trích xuất

- **P001181:** guard phủ định trộn background về in-domain accuracy với finding
  domain adaptation. Review thêm background vào contribution nhưng vẫn bị báo
  mất phủ định. Đây là false alarm về phạm vi, không thể coi cờ là nhãn sai tự động.
- **P002877:** matcher chặn `without using pivot translation` với reference
  không nhắc pivot, dù hai bên không đưa finding đối lập.
- **P001806:** cosine **0,9771** nhận finding few-shot với reference gồm cả
  finding zero-shot; phần zero-shot thực tế còn thiếu dù cặp được tính TP.
- **P003614:** abstract kết thúc giữa câu nhưng không được detector gắn cờ.
  Cách trích từng vế cũng khác reference gộp, gây thêm bất đồng.

Selected metadata có 55 thông báo source words/order, 1 phủ định, 1 coverage
và 28 thông báo chưa có valid review. Đây là thông báo kiểm tra, không phải
85 lỗi ngữ nghĩa độc lập.

## Ưu tiên sửa tiếp

1. Ngăn chép ví dụ và đổi feedback khi review bị lặp: đọc lại nguồn, tập trung
   item/facet/ID lỗi thay vì cùng full-JSON request. Giữ ngân sách đo được.
2. Khôi phục limitation thật và named resources theo nguồn; kiểm tra thêm
   resource được nêu trong findings. Giữ định nghĩa problem nhưng tránh xóa hết.
3. Rà artifact/finding âm riêng, giữ chủ thể/điều kiện và tránh nhãn mô tả thử nghiệm
   thay contribution. Thử chọn/lọc nhỏ trên raw trước khi đổi toàn bộ scoring.
4. Sửa phạm vi phủ định ở validator trong phép thử riêng; giữ evaluator/reference
   làm mốc, rồi review độc lập các cặp/reference bất đồng trước khi thay matcher.

Mức tăng micro-F1 còn nhỏ và che hồi quy problem/dataset. Chưa có human-confirmed
semantic F1; chưa có kiểm tra cohort mới để kết luận chất lượng toàn corpus.

## Bằng chứng

[Counts/delta và danh sách retry/leak](../../../data/exp_a/evaluation/pilot50_v3_4_ai_v1/error_analysis.json) ·
[15 ca với nguồn, nhãn và raw attempts](../../../data/exp_a/evaluation/pilot50_v3_4_ai_v1/review_cases.jsonl) ·
[Report evaluator](../../../data/exp_a/evaluation/pilot50_v3_4_ai_v1/report.md) ·
[Run và khôi phục kernel](KAGGLE_PILOT50_V3_4_RUN_2026-10-15.md)
