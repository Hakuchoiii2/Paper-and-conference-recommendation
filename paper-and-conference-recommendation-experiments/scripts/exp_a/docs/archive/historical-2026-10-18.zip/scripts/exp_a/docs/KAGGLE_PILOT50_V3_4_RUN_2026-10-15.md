# Pilot50 v3.4 — empty-output review, problem và hai T4

[Rà lỗi v3.4: 15 ca nguồn/raw, retry lặp, ví dụ bị chép và dataset bỏ sót](KAGGLE_PILOT50_V3_4_ERROR_REVIEW_2026-10-15.md).

**Kernel version 6 đã COMPLETE**, khôi phục đủ **50/50 bài** sau khi sửa lỗi
merge của version 5. Hai T4 ở v5 đã sinh xong 25 bài/card; lỗi chỉ xảy ra khi
merger lấy vị trí từ corpus 4.210 bài thay vì cohort 50 `paper_ids` được chọn.
Merger 1.1 lọc catalog theo cohort trước khi kiểm range/coverage.

Version 6 resume hai phần đã lưu, log xác nhận 25/25 saved trên mỗi GPU và
không có dòng nạp Qwen hay trích bài mới: **0 lượt sinh model mới**, giữ nguyên
130 raw generations của v5. Thời gian summary v6 là 7,63 giây cho resume/merge,
không phải thời gian inference 50 bài. Hai JSONL cuối tải về khớp byte bản khôi
phục local; manifest có cùng dữ liệu JSON, khác byte định dạng/newline.
**157 test qua** sau sửa; test bổ sung tái hiện cohort nằm trong corpus lớn hơn.

Source version 6 tải lại khớp SHA-256 bản gửi. Metadata remote xác nhận đúng owner
`htnkhi`, private, Internet bật và `machine_shape=NvidiaTeslaT4`.
Đây là [tên cấu hình T4 ×2 của Kaggle](https://github.com/Kaggle/kaggle-cli/blob/main/docs/kernels.md).
Input dataset đã ready trước khi push.

## Điểm sau khôi phục

Chấm cùng 50 ID, AI reference, evaluator và ngưỡng 0,85: **micro-F1 53,82%**,
so với v3.3 **52,57%**, tăng **1,25 điểm %**. Precision 62,50%, recall 47,26%;
TP/FP/FN = 190/114/212. Validation pass/fallback = 22/28, so với 31/19 ở v3.3.
Guard mới đổi tiêu chuẩn chấp nhận output rỗng, nên số validation pass không
được diễn giải trực tiếp thành chất lượng ngữ nghĩa thấp/cao hơn.

| Facet | F1 v3.3 | F1 v3.4 |
|---|---:|---:|
| Problem | 26,23% | **14,63%** |
| Task | 53,06% | 60,56% |
| Method | 57,38% | 61,54% |
| Dataset | 80,00% | **53,85%** |
| Contribution | 50,78% | 49,43% |

Điểm tổng tăng nhờ method/task, nhưng problem và dataset hồi quy. P001431 vẫn
trả năm facet rỗng; guard đã gắn fallback thay vì nhận là validation pass,
chưa phục hồi được nội dung. Chưa nên coi v3.4 tốt hơn đều hoặc mở rộng corpus.
[Report chấm](../../../data/exp_a/evaluation/pilot50_v3_4_ai_v1/report.md) ·
[Xác minh phục hồi](../../../data/exp_a/.kaggle/review/pilot50_v3_4_recovery_verification.json).

## Thay đổi được chạy

- Prompt **3.4**, guideline/scoring/ranking policy **3.1**, engine **3.5**.
- Output rỗng cả năm facet, kể cả sau dataset filter, cần review lại nguồn.
  Nếu vẫn rỗng sau ngân sách ba lượt thì lưu fallback và validation errors.
  Boilerplate tải sách đã nhận diện vẫn được phép rỗng. Guard chỉ gắn cờ
  completeness, không tự biết nguồn hỗ trợ facet nào và không ép lấp nhãn.
- Prompt/review phân biệt problem là limitation/question thúc đẩy nghiên cứu,
  task là việc thực hiện và contribution là artifact/finding. Tên nhiệm vụ có
  chữ “problem” hoặc finding âm không tự trở thành motivating problem.
  Limitation phải giữ chủ thể để hiểu độc lập.
- Giữ cách tách method và hướng dẫn contribution của v3.3; chưa triển khai lượt
  sửa contribution riêng. Giữ dataset filter và ngân sách tối đa ba lần sinh.
- Audit ghi prompt version dùng khi replay, kể cả lúc generator kiểm tra local
  metadata trước khi thêm provenance cấp paper. Các output v3.1/v3.2/v3.3 vẫn
  được replay theo policy/fingerprint đã biết.

## Chạy hai GPU

Mỗi child process thấy đúng một GPU qua `CUDA_VISIBLE_DEVICES=0` hoặc `1` và
nạp một bản Qwen riêng. Hai worker được khởi chạy trước khi chờ kết quả:

| Worker | Vị trí trong cohort 50 ID đã sắp xếp | Output |
|---|---|---|
| GPU 0 | 1–25 | `generated_v3_4_pilot50_parts/gpu_0/` |
| GPU 1 | 26–50 | `generated_v3_4_pilot50_parts/gpu_1/` |

Mỗi phần có checkpoint/audit riêng. Merger hiện có kiểm tra provenance,
coverage và ID trùng rồi mới xuất `data/exp_a/generated_v3_4_pilot50/`.
Worker lỗi không được xuất merged complete; checkpoint các phần được giữ.
Packager hỗ trợ mang các phần đã tải về vào input cho resume.

Runtime yêu cầu đúng hai T4; nếu Kaggle không cấp đủ thì báo lỗi rõ ràng.
Log v5 xác nhận hai Tesla T4 và hai worker đã sinh đủ 25 bài/card. Log v6
xác nhận hai GPU và resume đủ các phần, không gọi lại model. Chưa có benchmark
cùng prompt/settings để kết luận tăng tốc đúng 2×.

## Kiểm tra trước push

- **157 test qua:** 88 project + 69 exp_A; guard và lỗi merge có regression test.
- Kiểm trường hợp recover từ empty ở lượt ba, empty dai dẳng thành fallback,
  boilerplate rỗng hợp lệ, audit bị sửa, backward replay và migration đúng config.
- Kiểm chia cohort lẻ, gán GPU riêng, khởi chạy cả hai trước wait, merge output
  thật đủ ID/provenance và từ chối publish khi worker lỗi/thiếu GPU.
- Replay đủ bốn output: v3.1, v3.1 có filter, v3.2, v3.3.
- Bundle CRC/allowlist/hash/syntax đạt; không chứa reference hoặc credential.
  Review độc lập không còn Critical/Important finding.

Giữ nguyên 50 ID, corpus, model/revision, NF4, do_sample=false, seed, reference
AI source-only và evaluator/ngưỡng 0,85. Mốc so sánh là v3.3 đạt **52,57%**.
Pilot đã dùng phát triển; kết quả tiếp theo vẫn là agreement trên dev, chưa
phải đánh giá human semantic F1 độc lập.

[Push report](../../../data/exp_a/.kaggle/pilot/push_report.json) ·
[Xác minh phục hồi v3.4](../../../data/exp_a/.kaggle/review/pilot50_v3_4_recovery_verification.json) ·
[Kết quả v3.3](KAGGLE_PILOT50_V3_3_EVALUATION_2026-10-15.md)
