# Policy và ví dụ đối chiếu — vòng thử nghiệm v1

Người dùng đồng ý thử cải tiến quy tắc gán nhãn và ví dụ trước; fine-tuning để sau khi có kết quả. Vòng này dùng luồng joint five-facet hiện có, không dùng source-first đã hồi quy ở matrix v2.

## Đã chuẩn bị

- Rà lại title và toàn bộ evidence sentences của 20 ca khó. `data/exp_a/prompts/policy_audit_v1.json` ghi các nhãn nhận/loại, evidence ID và lý do. Đây là checklist từng phần do AI kiểm tra, không phải human gold hay bộ nhãn đầy đủ.
- Policy ngắn ở `data/exp_a/prompts/facet_policy_v1.md`: vai trò background/baseline/used method/new artifact/finding; method tách thành phần độc lập; contribution giữ điều kiện, phủ định, metric, so sánh và caveat.
- Bốn ví dụ tổng hợp ở `data/exp_a/prompts/policy_examples_v1.json`: phương pháp và feature riêng; artifact thuộc hai facet; positive/negative findings có điều kiện; nguồn download không phải nghiên cứu. Không sao chép nhãn của paper được chấm.
- Mọi concept được nhận trong checklist và ví dụ đều được kiểm tra bằng source grounding hiện có. Điều này chỉ xác nhận hỗ trợ từ nguồn, không thay thế thẩm định ngữ nghĩa của người.

## Ma trận cố định

| Nhánh | System instruction | Schema | Review |
|---|---|---|---|
| original | Prompt 3.7 đã chạy ở matrix v2, tái sử dụng output có hash | concept + evidence_id | Profile 3.7, tối đa 3 generations |
| policy | Policy ngắn v1 | Giống original | Giống original |
| policy_examples | Policy ngắn v1 + 4 ví dụ đối chiếu | Giống original | Giống original |

Original vốn không yêu cầu model sinh `span/kind`, nên không tạo một nhánh “bỏ span” giả trùng với nó. Vòng này giữ schema tối giản cho cả ba nhánh; tác động của policy và ví dụ được tách thành hai so sánh. Kết quả schema ablation trên bốn ca ở vòng trước vẫn chỉ là chẩn đoán nhỏ.

Kaggle chạy Qwen3-8B revision `b968826d9c46dd6066d109eabc6255188de91218`, NF4 double, FP16, greedy, thinking=false, seed42, 2048 new tokens, attention efficient không native GQA như matrix v2. Chỉ có hai nhánh mới cần sinh; original đã hoàn thành trước đó. Chi phí original được đánh dấu historical/reused.

20 paper dùng rà policy bị loại khỏi phần so điểm; 30 paper còn lại dùng cùng AI reference đã đóng băng. **Đây vẫn là dev đã từng dùng, không phải test mới độc lập.** Reference chỉ được đọc khi scoring, không đưa vào request generator. Embedding/scorer/threshold 0.85 và ghép một-một giữ nguyên.

Baseline original của riêng 30 paper:

| Model | TP | FP | FN | Micro F1 |
|---|---:|---:|---:|---:|
| 4B | 126 | 85 | 120 | 55.14 |
| 8B | 141 | 78 | 105 | 60.65 |

Không so trực tiếp score mới của 30 paper với score 56.36 của 8B trên cả 50 paper. Phải so các nhánh trong cùng ma trận.

## Kiểm tra và đọc kết quả

`policy_matrix.py` tái sử dụng annotate/review, source validator, signed checkpoint, loader và semantic scorer hiện có. Có test cho tách policy/evaluation, ví dụ khớp nguồn, hash bundle và luồng extract/review giữ evidence. Hồi quy: 104 test exp_A và 88 test project đã qua; sau thay đổi đường cache local, ba test mới đã chạy lại và qua.

Probe local cố định trước khi xem điểm: 4B trên P000681, P001211, P002273, P003614, ngoài 20 ca policy. Original tái sử dụng từ T4; nhánh mới sinh trên RTX4060, nên kết quả local chỉ để chẩn đoán. Không sửa prompt theo điểm probe rồi gọi phần còn lại là test chưa thấy.

Đọc micro, macro, P/R và F1 từng facet, nhất là method/contribution; xem FP/FN thay đổi theo source và fallback flags. Không tự động chọn winner chỉ vì điểm tổng. Không fine-tune trong kernel này. Nếu vẫn thấp, dùng kết quả để xác định dữ liệu SFT cần bổ sung, tránh huấn luyện trực tiếp toàn bộ AI reference chưa thẩm định.

## Kết quả local đã chạy

| Nhánh 4B, cùng 4 bài | TP | FP | FN | Micro F1 | Method F1 | Contribution F1 | Fallback |
|---|---:|---:|---:|---:|---:|---:|---:|
| original, tái sử dụng | 20 | 10 | 18 | 58.82 | 50.00 | 64.00 | 3/4 |
| policy | 14 | 11 | 24 | 44.44 | 31.58 | 58.33 | 3/4 |
| policy_examples | 8 | 9 | 30 | 29.09 | 22.22 | 50.00 | 1/4 |

**Hai biến thể chưa cải thiện trên probe này.** Ít fallback hơn không đồng nghĩa khôi phục đủ nhãn. Policy-only mất 6 TP và thêm 1 FP; thêm ví dụ mất 12 TP so original trong khi chỉ giảm 1 FP. Không chọn hai nhánh mới thay baseline 4B từ kết quả này.

Các hiện tượng nhìn thấy trực tiếp:

- P002273: original giữ ba finding độc lập; policy_examples gộp ba finding vào một câu dài. Ghép một-một không thể tính một label là ba TP. Cần dữ liệu/ví dụ dạy tách nhiều finding trong cùng evidence sentence, không chỉ tách theo sentence ID.
- P001211: policy_examples bỏ cả task và method, trong khi vẫn sinh nhiều contribution. Một số phương pháp nằm trong câu kết quả, nên quy tắc loại background/procedure có thể bị áp dụng quá rộng. Đây là giả thuyết từ mẫu, chưa phải tỷ lệ lỗi toàn corpus.
- P003614: policy_examples còn problem nhưng task/contribution rỗng. Policy-only cũng tạo claim gộp từ nhiều câu, dẫn đến evidence ID không hỗ trợ đủ concept.
- P000681: model chuyển câu bị động thành cụm danh hóa/đảo thứ tự từ, không qua hợp đồng ordered-source. Đây là lỗi biểu diễn/grounding; không nên gọi tất cả các nhãn này là sai nghĩa.

Luồng fallback 3.7 có thể giữ label bị gắn quality flags trong best-available output; scorer hiện tại vẫn chấm những label đó. Vì vậy benchmark agreement không thay thế việc đọc flags và source. Không thay validator giữa các nhánh để che sự khác biệt này.

Artifacts local được giữ ở `data/exp_a/evaluation/policy_matrix_local_v1/`: bảng CSV/Markdown, evaluation từng nhánh, records và verification. Đây là 4 ca chọn sẵn trên 4B, baseline T4 tái sử dụng so với sinh mới RTX4060; không suy rộng thành kết luận cho 8B/30 bài.

## Đính chính ý nghĩa phép thử và chẩn đoán mức giảm local

Nhánh policy **thay thế** guideline + prompt 3.7 bằng policy v1; không phải original + một đoạn policy bổ sung. Original đã có định nghĩa facet, ví dụ và nhiều chỉ dẫn coverage được sửa qua các vòng trước. Vì vậy so original với policy đồng thời thay cách diễn đạt, mức chi tiết và bộ ví dụ cũ; chưa cô lập được tác dụng của việc thêm policy. So policy với policy_examples chỉ thêm bốn ví dụ, cùng GPU local, và cũng giảm điểm trên bốn ca này.

Đã tái dựng TP/FP/FN từ evaluation từng paper qua hàm metrics hiện có: original 20/10/18; policy 14/11/24; policy_examples 8/9/30, cùng 38 nhãn reference. Mức giảm chủ yếu đi cùng mất nhãn khớp, không được bù bằng giảm nhãn thừa. First-pass input tokens của P000681 lần lượt 2382/1057/1986; cả ba paper khác cũng có original dài hơn hai nhánh mới. Chưa có bằng chứng cho giải thích “chỉ vì prompt quá dài”.

Raw audit xác nhận P001211 policy_examples đã để task/method rỗng từ extract, không phải parser xóa chúng sau khi sinh. P002273 gộp ba finding ngay trong raw thành một label; các ví dụ mới không có trường hợp nhiều finding độc lập trong cùng evidence sentence. Đây là dấu hiệu về coverage/granularity, chưa xác định được câu hướng dẫn hoặc ví dụ cụ thể gây ra toàn bộ hiệu ứng.

Có thêm tương tác với review profile 3.7: `review_facets` mặc định mở problem/dataset/method/contribution, nhưng task chỉ mở nếu có validation error tương ứng (hoặc schema/coverage lỗi toàn cục). Task=[] hợp lệ không được mở lại. Audit P001211 và P003614 cho thấy task không nằm trong review scope ở nhánh có ví dụ. Method/contribution vẫn được mở nhưng model cũng không phục hồi chúng; không thể quy mọi mất nhãn cho cơ chế khóa task.

Phép đối chứng cần bổ sung sau vòng đang chạy: original giữ nguyên + từng rule/ví dụ bổ sung, so với original sinh mới trên cùng phần cứng/backend. Chưa thực hiện đối chứng đó, chưa sửa review profile trong matrix v4 và chưa có cơ sở kết luận fine-tuning là bắt buộc từ probe bốn ca.

## Kaggle và lỗi đóng gói đã sửa

Người dùng đã xác nhận cụ thể tải gói lên dataset riêng tư `htnkhi/exp-a-qwen-facet-matrix-inputs` và chạy kernel riêng tư `htnkhi/exp-a-qwen-facet-matrix`.

Version 3 lỗi ở bước import: `policy_matrix.py` import `build_matrix`, một module chỉ phục vụ đóng gói ở local. Log tại `.kaggle/review/policy_v3_failure/` xác nhận `ModuleNotFoundError`. Đã chuyển import vào hàm build và thêm kiểm tra import từ zip trong subprocess isolated; test tái hiện đỏ rồi qua. Prompt, policy, ví dụ, scorer và cohort không đổi do bản sửa này.

**Version 4 đã COMPLETE và được kiểm tra local.** Gói sửa có generation signature `22c5003b392245266c4ec34415e5e2b83cf729329798769e4eab69615c196ea7`, bundle SHA256 `6c57e37c810e6a8ffcf6ae54845641bf76ff969ea938e5035cb9189802c586c4`. Đủ 90 signed records, 60 raw replay và 450 ô scoring. Original/policy/policy_examples đạt micro 60,65/50,43/52,51%; original vẫn tốt nhất. Xem [báo cáo kết quả](KAGGLE_POLICY_MATRIX_V4_EVALUATION_2026-10-16.md). Người dùng đã yêu cầu không sửa phép thử thành original + policy; chưa chạy phép đối chứng đó. Output local `data/exp_a/evaluation/policy_matrix_kaggle_v4/`; report trạng thái ở `.kaggle/matrix/policy_push_report.json`.

Chưa fine-tune và chưa thay handoff production. Nếu 8B vẫn thấp, các lỗi này là đầu vào để thiết kế dữ liệu SFT có policy nhất quán; không coi việc fine-tune trên AI reference hiện tại là bảo đảm tăng chất lượng.
