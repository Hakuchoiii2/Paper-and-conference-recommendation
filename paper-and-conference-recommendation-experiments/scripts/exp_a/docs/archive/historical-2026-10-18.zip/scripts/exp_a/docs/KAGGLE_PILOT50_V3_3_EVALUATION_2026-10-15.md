# Pilot50 v3.3 — tăng nhẹ, còn lỗi vai trò và độ đầy đủ

Kaggle kernel version 4 đã **COMPLETE**, tải đủ output và log. Prompt 3.3 đạt
**52,57% embedding micro-F1**, so với **51,89%** của v3.1 có dataset filter:
tăng **0,68 điểm phần trăm**. Method cải thiện, problem hồi quy; contribution
gần như đứng yên. Đây là agreement với reference AI trên pilot đã dùng phát
triển prompt, chưa phải semantic accuracy được người xác nhận.

## Run và kiểm tra output

- Kernel: `htnkhi/exp-a-qwen-v3-pilot50`, version 4; prompt 3.3, guideline/policy
  3.1, engine 3.4, `dataset_resource_filter=true`.
- **50/50 bài**, không missing/failed; **31 validation pass, 19 fallback**.
  Giữ đủ **126 raw generations**: 24 bài dùng hai lượt, 26 bài dùng ba lượt.
- Thời gian inference **3.948,17 giây**, khoảng **65,8 phút**. Dataset filter
  loại 7 item và lưu audit. Bộ dò nguồn gắn cờ 2 bài, không có nghĩa 48 bài còn
  lại sạch nguồn.
- Code, config, prompt, guideline, corpus và selection tải về khớp SHA-256 local.
  Hai JSONL khớp manifest; bản sao chuẩn khớp byte bản tải; cả 50 audit khớp
  metadata. `build_exp_a.py --validate-only` replay thành công toàn bộ 50 bài.
- Output chuẩn: `data/exp_a/generated_v3_3_pilot50/`. Giữ output các bản trước.
  `last_failure.json` là audit fallback cuối của P004047, không phải lỗi runtime
  khiến run thiếu bài. Manifest cuối và Kaggle summary đều complete.
- Lần tải đầu vướng encoding khi ghi log trên Windows; dữ liệu chính đã tải và
  được kiểm hash. Tải lại riêng log với `PYTHONUTF8=1` thành công, exit code 0.

## So cùng điều kiện chấm

Giữ nguyên 50 ID, reference AI source-only v1 gồm **402 concept**, evaluator,
Qwen3-Embedding-0.6B/revision/model hashes và cosine **0,85**. Hash reference và
evaluator khớp tất cả các mốc dưới đây. Không sửa nhãn hoặc ngưỡng để nâng điểm.

| Chỉ số | Silver cũ | v3.1 | v3.1 + filter | v3.2 | v3.3 |
|---|---:|---:|---:|---:|---:|
| Precision | 48,72% | 55,72% | 59,49% | 40,06% | **57,74%** |
| Recall | 33,08% | 46,02% | 46,02% | 32,59% | **48,26%** |
| Micro F1 | 39,41% | 50,41% | 51,89% | 35,94% | **52,57%** |
| TP / FP / FN | 133 / 140 / 269 | 185 / 147 / 217 | 185 / 126 / 217 | 131 / 196 / 271 | **194 / 142 / 208** |

So với v3.1 có filter: thêm 9 TP, thêm 16 FP, giảm 9 FN; recall tăng nhưng
precision giảm. Macro F1 v3.3 là 53,49%, exact lexical micro-F1 là 23,31%.
Theo F1 từng bài: **21 tăng, 21 giảm, 7 bằng**; một bài boilerplate hai phía
cùng rỗng nên F1 không xác định. Không tính bài đó thành 100% chất lượng.

| Facet | F1 v3.1 + filter | F1 v3.3 | Đổi (điểm %) | TP / FP / FN v3.3 |
|---|---:|---:|---:|---:|
| Problem | 38,60% | **26,23%** | **−12,37** | 8 / 22 / 23 |
| Task | 52,55% | 53,06% | +0,51 | 39 / 24 / 45 |
| Method | 51,82% | **57,38%** | **+5,56** | 70 / 30 / 74 |
| Dataset | 83,87% | 80,00% | −3,87 | 12 / 2 / 4 |
| Contribution | 50,62% | 50,78% | +0,16 | 65 / 64 / 62 |

FP/FN là bất đồng của matcher, không phải số lỗi ngữ nghĩa đã adjudicate.
Trong 350 FP+FN, contribution chiếm 126 (36,0%), method 104 (29,7%), task 69
(19,7%), problem 45 (12,9%), dataset 6 (1,7%). Vì vậy **problem yếu nhất theo
F1**, còn **contribution và method lớn nhất theo lượng bất đồng**.

## Các lỗi chính còn lại

### 1. Nhầm vai trò facet và bỏ ý chính; validator vẫn có thể cho qua

- **P001431:** extract và review đều trả năm facet rỗng, không có lỗi validator,
  `validation_passed=true`, dù nguồn nêu classification schema, synthesis of
  literature và mục tiêu examine classification schema. Đây là bỏ sót thực sự;
  validator không có kiểm tra đầy đủ nội dung khi mọi list rỗng.
- **P001806:** `few-shot action recognition` và `zero-shot action recognition`
  xuất hiện cả ở task và problem. Nguồn gọi chúng là problems theo nghĩa nhiệm
  vụ; chưa nêu limitation để chốt problem theo guideline. Contribution không
  ghi artifact TARN được đề xuất và bỏ finding competitive zero-shot results.
- **P000669:** problem lấy mục tiêu phân tích contribution of semantic roles.
  **P002471** đưa finding “no more effective … than text explanation” vào
  problem; **P003187** tương tự với finding “80% had no training”.
- **P003661:** problem là câu công việc “relative advantages and disadvantages
  … are discussed”, trong khi hạn chế về giả định normality bị đưa vào
  contribution. Sửa chữ qua ba lượt vẫn chưa sửa đúng vai trò.
- **P001389:** contribution chỉ ghi finding hiệu quả, bỏ artifact JTV dù có JTV
  ở method. Task giữ mục tiêu mining rộng, thiếu identification/clustering cụ thể.

Problem tăng 26 → 30 nhãn nhưng TP giảm 11 → 8, FP tăng 15 → 22. Đây là phần
hồi quy rõ nhất, gồm cả nhầm vai trò, nhãn thiếu chủ thể và bất đồng độ chi tiết.

### 2. Contribution nhiều hơn nhưng độ đầy đủ/độ chi tiết chưa ổn

Số nhãn contribution tăng 114 → 129; chỉ thêm 4 TP nhưng thêm 11 FP. Độ dài
trung vị tăng 16 → 18 từ. Có cả chép dài, tách vụn, trùng ý và bỏ artifact.

- **P003441:** có 8 contribution mô tả gần hết thiết kế LightRocks; reference
  giữ 3 đóng góp. Một số extra có căn cứ trong nguồn, nên không gọi cả 6 FP của
  facet này là hallucination. Cần thống nhất mức tách concept và novelty.
- **P002380:** array parameter solution và modularization facility có trong
  một nhãn contribution dài, nhưng không match ba reference tách. Hai ý này
  **không bị mất khỏi văn bản trích xuất**; điểm thấp có phần do cách tách/gộp.
- **P002471:** finding dương/âm tách thành hai nhãn, vế âm còn “it … at this”
  nên thiếu chủ thể khi đọc độc lập; artifact web tutor không được ghi.
- **P000681:** chỉ giữ “best results … compound analysis”, thiếu mức cải thiện
  Recall và caveat không giảm Precision. Đây là thiếu nội dung, không chỉ khác chữ.

### 3. Method đã gọn hơn nhưng vẫn thiếu hoặc mất quan hệ

Trung vị độ dài method giảm 5 → 3 từ; TP tăng 64 → 70, FP giảm 39 → 30. Ví dụ
**P000669** đã tách đúng CRF, morphosyntactic features, semantic roles features;
cả ba match exact. Nhưng vẫn còn 74 FN theo matcher.

- **P003441:** review cuối bỏ `Statechart like model` khỏi method, chuyển sang
  mô tả contribution, và vẫn gộp UML/P với MontiCore.
- **P001806:** `attention mechanisms` và `deep-distance measure` quá ngắn để giữ
  temporal alignment và aligned representations at video segment level.
- **P002877:** chỉ có neural interlingua ở method, thiếu multilingual
  encoder-decoder architecture và source sentence embeddings cho review classifier.

Không nên ép mọi method chỉ còn tên một từ: giữ kỹ thuật riêng biệt cùng phần
quan hệ/setting cần để hiểu đúng cách dùng.

### 4. Self-review chủ yếu còn sửa chữ, chưa bảo đảm completeness

Còn **19/50 fallback**. Metadata của selected raw attempts có 45 thông báo
source words/order và 1 thông báo phủ định, cùng 19 thông báo chưa có review
hợp lệ. Đây là cờ validation, không phải 46 lỗi ngữ nghĩa đã xác nhận.

**11/19 bài fallback** có hai raw response liền nhau giống hệt; P002380,
P002471, P002877 và P003085 thậm chí lặp nguyên cả ba lượt. P002877 bỏ WMT15
và Yelp reviews khỏi dataset trong cả ba lượt dù tên nằm ngay trong nguồn.
P001431 cho thấy review rỗng vẫn có thể được nhận. Thêm lượt sinh với feedback
hiện tại chưa chắc sửa được phần bỏ sót.

### 5. Dataset không còn là nút thắt lớn, nhưng filter vẫn có lỗ hổng

Dataset F1 80%, chỉ 2 FP/4 FN theo chính sách đang chấm. **P003211** vẫn nhận
“brain data … playing Dota 1”: Dota 1 là tên trò chơi, chưa phải tên resource.
**P003308** giữ “real world data from UCI repository”, chưa xác định dataset cụ
thể. **P002877** bỏ hai resource đã nêu; WSJ Penn Treebank/MUC7 newspaper corpus
là các missing khác, có yếu tố background/quan hệ dẫn xuất cần thống nhất policy.

## Phần đã cải thiện và giới hạn của phép chấm

- **P004047** đã giữ finding “did not obtain higher BLEU scores … than …
  word-based approach”, trước đó bị bỏ. Còn nguồn vỡ từ và contribution gộp/trùng.
- **P002586** đã giữ Tamil cùng điều kiện test data nhiều hơn training data.
  Còn thiếu finding thí nghiệm sáu ngôn ngữ và bottleneck features ở method.
- **Matcher bỏ nhầm:** P002877 bị `negation_mismatch` vì silver có “without
  using pivot translation”, reference không nhắc pivot; đây không phải hai
  finding đối lập. Không sửa matcher/ngưỡng trong lần so này.
- **Matcher nhận quá rộng:** P001806 chỉ ghi finding few-shot nhưng được ghép
  với reference gồm cả finding zero-shot, cosine **0,9771**. Vì thế 194 TP không
  đồng nghĩa 194 cặp đã tương đương đủ nghĩa.
- **Validator báo nhầm phạm vi:** P001181 đòi giữ phủ định về in-domain accuracy
  trong finding hiệu quả domain adaptation; hai vế có phạm vi khác nhau.
- **Nguồn chưa sạch:** P001211 có `bri le`, `a acks`; P003614 kết thúc giữa câu
  ở “hearer will come to”; đều `no_flag_detected`. Cờ nguồn 2 bài không thay
  thế việc xác minh nguồn.

## Ưu tiên tiếp theo

1. Chặn bỏ trắng thiếu căn cứ và review completeness theo nguồn: task chính,
   kỹ thuật, artifact được giới thiệu, findings dương/âm và điều kiện.
2. Sửa problem theo limitation/question thật; tách task/finding ra đúng vai trò.
   Đọc thêm ngữ cảnh để nhãn tự hiểu được, không chỉ lấy một vế có từ nguồn.
3. Giữ cách tách method đã có lợi; sửa contribution theo đơn vị ý nghĩa,
   bổ sung artifact và tránh gộp/trùng hoặc tách chủ thể khỏi comparator.
4. Rà độc lập cặp/reference có bất đồng độ chi tiết và phạm vi phủ định trước
   khi quyết định thay matcher. Giữ mốc chấm này để so công bằng.

Mức tăng 0,68 điểm % trên dev, với 21 bài tăng và 21 bài giảm, chưa đủ để khẳng
định v3.3 cải thiện đều hoặc quyết định chạy toàn corpus. Chưa chạy lại Qwen,
push Kaggle hoặc sửa generator/prompt/reference/evaluator trong lượt kiểm tra này.

## Bằng chứng lưu lại

- [Report evaluator](../../../data/exp_a/evaluation/pilot50_v3_3_ai_v1/report.md),
  `summary.json`, `manifest.json`, `per_paper.jsonl` nằm cùng thư mục.
- [Phân tích counts và delta từng bài](../../../data/exp_a/evaluation/pilot50_v3_3_ai_v1/error_analysis.json).
- [16 ca review có nguồn, nhãn và matched/rejected pairs](../../../data/exp_a/evaluation/pilot50_v3_3_ai_v1/review_cases.jsonl).
- [Xác minh Kaggle, hash và replay](../../../data/exp_a/.kaggle/review/pilot50_v3_3_verification.json).
- [So các phiên bản](../../../data/exp_a/evaluation/pilot50_comparison_ai_v1/comparison.json).

Đã kiểm lại tổng TP/FP/FN từ từng bài và từng facet, công thức F1, hash input,
hash output chấm và tính đồng nhất evaluator/reference/model giữa các lượt.
Review thủ công AI có chủ đích ở 16 ca, không phải adjudication độc lập toàn bộ
350 FP/FN hoặc đánh giá human semantic F1.
