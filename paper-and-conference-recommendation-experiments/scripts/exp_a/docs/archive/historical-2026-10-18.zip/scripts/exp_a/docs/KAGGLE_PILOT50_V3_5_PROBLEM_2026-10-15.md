# Pilot50 v3.5 — ưu tiên problem

## Mục tiêu và mốc so

Người dùng yêu cầu ưu tiên cải thiện problem. Mốc v3.4: problem TP/FP/FN
**3/7/28**, precision **30%**, recall **9,68%**, F1 **14,63%**; 43/50 bài để
problem rỗng. Micro-F1 toàn bộ **53,82%**. Một phần bất đồng là do policy hoặc
reference AI; không coi toàn bộ FN là lỗi đã được người xác nhận.

## Thay đổi hẹp

- Prompt 3.5 nhận diện hạn chế của phương pháp/giả định hiện có, đe dọa validity,
  yêu cầu chưa đáp ứng, khó khăn tính toán hoặc câu hỏi còn mở mà công trình
  thực sự giải quyết. Hạn chế có thể là câu khẳng định trong background;
  không bắt buộc có dấu hỏi hoặc chữ “we address”. Liên hệ với mục tiêu của bài
  phải có căn cứ trong title/abstract.
- Trước khi chấp nhận problem=[], đọc lại toàn bộ nguồn. Nếu bỏ một nhãn sai,
  tìm limitation thật thay vì mặc nhiên thay bằng rỗng. Giữ chủ thể, hạn chế và
  điều kiện trong một evidence sentence; dùng span dài hơn khi rút gọn mất nghĩa.
- Tách limitation đã biết khỏi finding mới. Task/topic hoặc kết quả âm mới
  không tự động trở thành problem. Giữ [] khi nguồn thực sự không hỗ trợ.
- Bỏ nhóm ví dụ problem, gồm câu ranker/vocabulary đã bị chép vào ba draft;
  giữ các ví dụ hướng dẫn các facet còn lại.

Giữ nguyên model/revision, NF4, greedy decoding, seed42, ngân sách ba lần,
cohort 50 ID, guideline3.1, scorer/ranking/validator policy3.1, dataset filter,
evaluator, AI reference và ngưỡng0.85. Không thêm guard ép problem khác rỗng,
không chèn ID hay câu trả lời của pilot vào prompt.

Prompt: `data/exp_a/prompts/extraction_v3_5.md`. Engine3.6 bổ sung routing3.5
và migration bằng hash xác định cho các phiên bản cũ; thay đổi prompt/config
không được phép tái sử dụng annotation3.4 làm3.5.

## Chạy và đánh giá

**Kernel version 7 đã COMPLETE**, tải đủ 50 bài và replay audit thành công.
Log/summary xác nhận hai **Tesla T4** thực tế, mỗi GPU 25 bài; thời gian inference
và merge **2.282,67 giây (~38 phút)**. Có 127 generations, 24 validation pass,
26 fallback; không thiếu ID, không có failed annotation hay lỗi runtime merge.
Source tải lại khớp hash bản gửi; corpus/reference/evaluator và các output cũ
khớp snapshot trước push.
Output mới `data/exp_a/generated_v3_5_pilot50/`, hai phần
`generated_v3_5_pilot50_parts/gpu_0/` và `gpu_1/`, mỗi GPU25 bài.
Bundle có13 file, không chứa reference hoặc output cũ: đây là run sinh mới,
không phải merge/resume nhanh như kernelv6.

159 test qua (88 project +71 expA); bốn output3.1–3.4 replay đủ50 bài mỗi bản.
Hai test mới kiểm tra routing, guard output rỗng, audit, filter và provenance;
chúng không đo chất lượng semantic của model.

Đã chấm cùng Qwen embedding/reference/ngưỡng 0,85, rà các bất đồng problem và
delta TP từng facet; lưu 21 ca với nguồn và toàn bộ raw attempts để đối chiếu.
Không sửa nhãn, reference, evaluator hoặc generator trong lượt kiểm tra này.

## Kết quả

| Facet | F1 v3.4 | F1 v3.5 | TP / FP / FN v3.5 |
|---|---:|---:|---:|
| Problem | 14,63% | **43,14%** | 11 / 9 / 20 |
| Task | 60,56% | 57,97% | 40 / 14 / 44 |
| Method | 61,54% | 61,86% | 73 / 19 / 71 |
| Dataset | 53,85% | **36,36%** | 4 / 2 / 12 |
| Contribution | 49,43% | 48,09% | 63 / 72 / 64 |
| Micro | 53,82% | **53,88%** | 191 / 116 / 211 |

Problem tăng **28,50 điểm % F1**, precision **30% → 55%**, recall
**9,68% → 35,48%**. TP **3 → 11**, FP **7 → 9**, FN **28 → 20**.
Problem rỗng giảm **43 → 36 bài**; số bài reference có problem nhưng prediction
rỗng giảm **21 → 15**. Không còn câu ranker/vocabulary trong cả 127 raw attempts.

Micro chỉ tăng **0,054 điểm %**: phần tăng 8 TP problem bị bù bởi task -3 TP,
dataset -3 TP, contribution -2 TP; method +1 TP. Tổng nhãn 304 → 307,
TP 190 → 191, FP 114 → 116, FN 212 → 211. Hướng problem có tiến bộ nhưng
chưa giải quyết chất lượng tổng thể. Hướng dẫn các facet khác không đổi;
việc sinh lại toàn bộ JSON vẫn làm các nhãn khác thay đổi.

## Problem đã phục hồi và lỗi còn lại

- **P000332/P001903:** phục hồi threat to internal validity và hạn chế phát hiện
  một entity pair trên short span. Đây là limitation rõ trong nguồn.
- **P000897/P001181:** lấy được limitation cụ thể của giải pháp end-to-end và
  self-training in-domain. **P003661** phục hồi ý normality assumption không
  hợp lệ hoàn toàn, nhưng cụm sinh ra vẫn sai source word/order và được gắn fallback.
- **P001484:** đã lấy limitation “this measure ... intrinsically inadequate”,
  nhưng span dài, chủ thể còn phụ thuộc câu trước và kết thúc ở “viz.”; chưa
  ghép được với reference nói rõ phép đếm token. **P002652** vẫn bỏ known NP-hard.
- **P001431/P002297/P003308/P003809:** vẫn bỏ các hạn chế có nguồn về thiếu
  định nghĩa chuẩn, dialogue là challenging context, massive-data challenge và
  local minimum của progressive alignment. Không phải mọi reference problem
  rỗng đều là lỗi: một số còn khác policy giữa topic/task/limitation.
- **P000781:** đưa finding mới của moderator analysis sang problem, sai vai trò.
- **P003614:** tách thành năm problem, có ý trùng nhau hoặc quá mơ hồ, trong khi
  reference gộp thành hai. FP ở đây không đồng nghĩa tất cả ý đều bịa.

**P003673 là lỗi đáng chú ý:** nguồn hỏi *whether* mô hình học syntax, draft lại
khẳng định *does not learn*. Review 2/3 đã trả lại whether nhưng vẫn bị lỗi lexical
do encoderdecoder/encoder-decoder. Cả ba attempt có cùng rank `(68.5, True, -1)`;
fallback chọn draft đầu và giữ khẳng định sai. Matcher vẫn tính TP với cosine
0,955 vì guard phủ định hiện áp dụng cho contribution, không kiểm tra trạng thái
câu hỏi ở problem. Vì vậy 11 TP là số ghép theo matcher, không phải 11 nhãn đã
được người xác nhận đúng. Lỗi này đã có ở v3.4, không phải 3.5 mới gây ra.

Một phần tăng TP đến từ cách diễn đạt/tách nhãn phù hợp reference hơn: P001604
đã chứa limitation đó ở v3.4 nhưng câu dài hơn không ghép được. Không diễn giải
toàn bộ +8 TP thành tám ý hoàn toàn mới được phát hiện.

## Hồi quy các facet khác và self-review

Dataset mất đúng ba TP so với v3.4:

- **P003085:** Inria Aerial Image Labeling Benchmark vắng ở cả hai raw attempts.
- **P003565:** Prague Dependency Treebank vắng ở cả hai raw attempts.
- **P003579:** draft có hai resource nhưng đảo thứ tự từ so với nguồn; review
  sửa bằng cách gộp NLPCC2014/Reuters vào một nhãn, chỉ ghép được một resource.

Đây là lỗi bỏ sót/tách nhãn khi sinh và review, không phải filter xóa đúng tên.
BioNLP/BioCreative ở P001903 và Europarl ở P004047 vẫn bị bỏ; UCI repository
chung chung và brain data khi chơi Dota vẫn lọt filter. Dataset nay là facet
có F1 thấp nhất. Task còn lỗi mất mục tiêu độc lập (all-mention-pairs ở P001903,
syntactically-controlled generation/paraphrasing ở P001506) và câu trích quá
dài/lẫn procedure. Không coi mọi TP giảm là mất nội dung thật vì matcher còn
nhạy với cách diễn đạt.

P004047 đã phục hồi negative BLEU finding trong cả ba attempt, dù prompt chỉ
chỉnh problem; đây là một cải thiện ngoài facet đích. Contribution tổng vẫn
giảm nhẹ do các bất đồng khác.

**20/26 fallback** có hai raw responses liền nhau giống hệt; **11 bài** có draft
và review đầu cùng raw/errors, khiến request cho review cuối lặp lại. Tăng
ngân sách đơn thuần chưa có căn cứ sẽ sửa được các ca này.

## Hướng tiếp theo

Giữ hướng định nghĩa problem của 3.5. Ưu tiên sửa review/fallback: bảo toàn
whether, phân biệt finding mới, đổi feedback khi lặp và thử tiebreak trên raw
đã lưu trước khi thay ranking toàn bộ. Tiếp đó phục hồi/tách từng named resource
từ mọi câu nguồn, đặc biệt câu kết quả. Nên sửa từng facet và giữ các nhãn đúng
của facet khác thay vì lại viết toàn bộ output, rồi đo tác động bằng một run
riêng. Chưa triển khai thêm hoặc push run mới trong lượt kiểm tra này.

Điểm là agreement với AI reference trên cohort phát triển; cần người chốt các
ca bất đồng và cohort mới trước khi suy rộng ra toàn corpus.

## Bằng chứng

[Report evaluator](../../../data/exp_a/evaluation/pilot50_v3_5_ai_v1/report.md) ·
[Counts/delta](../../../data/exp_a/evaluation/pilot50_v3_5_ai_v1/error_analysis.json) ·
[21 ca nguồn/raw](../../../data/exp_a/evaluation/pilot50_v3_5_ai_v1/review_cases.jsonl) ·
[Xác minh hoàn tất](../../../data/exp_a/.kaggle/review/pilot50_v3_5_completion_verification.json)
