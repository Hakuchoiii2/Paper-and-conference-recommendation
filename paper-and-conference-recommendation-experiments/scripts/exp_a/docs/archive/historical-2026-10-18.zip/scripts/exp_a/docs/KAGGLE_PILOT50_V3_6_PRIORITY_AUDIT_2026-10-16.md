# V3.6 — lỗi tập trung ở đâu và nên sửa gì tiếp

Đối chiếu lại output50 bài: **contribution và method chiếm69,75% tổng FP+FN**.
Contribution có nhiều bất đồng nhất; method nghiêng rõ về thiếu nội dung.
Ưu tiên lượt sửa tiếp là **coverage của method/contribution và cơ chế review**.
Dataset chỉ còn1,85% số bất đồng, chưa phải nơi có tác động lớn nhất lên micro-F1.

## Phân bố toàn cohort

| Facet | FP | FN | FP+FN | Tỷ trọng | Bài có bất đồng |
|---|---:|---:|---:|---:|---:|
| Contribution | 68 | 65 | **133** | **41,05%** | 43/50 |
| Method | 14 | 79 | **93** | **28,70%** | 45/50 |
| Task | 16 | 45 | 61 | 18,83% | 34/50 |
| Problem | 11 | 20 | 31 | 9,57% | 23/50 |
| Dataset | 2 | 4 | 6 | 1,85% | 6/50 |
| Tổng | 111 | 213 | 324 | 100% | — |

Đây là **bất đồng theo matcher/reference AI**, không phải324 lỗi ngữ nghĩa đã
được adjudicate. Một cặp tương đương bị matcher bỏ có thể tạo đồng thời1 FP và
1 FN. Tỷ trọng trên dùng xếp chỗ cần kiểm tra, không phải tần suất hallucination.
Problem có F1 thấp nhất nhưng lượng bất đồng nhỏ hơn contribution/method.

## Contribution: thiếu artifact/finding và khác cách biểu diễn đang trộn nhau

Đã rà toàn bộ65 reference labels bị tính FN, đọc nguồn và selected output rồi
ghi triage theo từng nhãn. Phân loại bởi AI, cần người xác nhận:

| Nhóm triage | Số nhãn | Ý nghĩa |
|---|---:|---|
| Chưa thể hiện trong contribution | **29** | Ý không được biểu đạt ở facet này; có thể vẫn có ở method/task |
| Mới thể hiện một phần hoặc chưa rõ | **14** | Thiếu điều kiện, định danh/vai trò artifact, hoặc tính cụ thể của claim |
| Nội dung có, cần rà cách biểu diễn/ghép | **22** | Ý còn trong nhãn dài, bị tách/gộp hoặc matcher không nhận; chưa khẳng định equivalent |

**Thiếu artifact là cụm đáng sửa trước.** Đã kiểm tám ca rõ bằng nguồn và toàn
bộ raw attempts: novel vision model(P001057), JTV(P001389), POS tagging tool
(P001409), TARN(P001806), generalized Polya process(P001948), reinforcement
learning approach(P003002), MCMM(P003308), freely available scripts(P003809).
Artifact được giới thiệu rõ trong nguồn nhưng không được biểu đạt như contribution
ở bất kỳ attempt đã lưu nào. Đổi ranking hoặc chọn lại attempt không phục hồi
được tám ca này. Một số artifact đã có ở method; không cần loại nó khỏi
contribution khi nguồn hỗ trợ cả hai vai trò.

Thiếu findings cũng có căn cứ: P001211 bỏ adversarial training does not completely
mitigate attacks; P004047 bỏ negative BLEU finding; P003199 bỏ kết quả snow cover
random fields/statistical self-similarity. P001806 còn mất finding zero-shot,
dù matcher ghép finding few-shot với reference gồm cả hai và tính TP.

Không nên sửa cả65 FN bằng cách ép sinh thêm nhãn. Ví dụ:

- P000669 đã có đúng hai con số F1 nhận diện/phân loại trong contribution;
  cặp vẫn bị tính FP/FN do phép ghép.
- P002380 có array parameter solution và modularization facility trong một
  nhãn dài; hai ý không hoàn toàn biến mất khỏi output.
- P003187 giữ80% chưa được đào tạo và attitude you stab my back… trong nhãn
  dài; không coi các FN tương ứng là bằng chứng model chưa từng lấy những ý đó.
- P003441 có9 contribution, gồm nhiều chi tiết thiết kế/procedure. Đây là
  vấn đề vai trò/độ chi tiết cần rà; không thể kết luận mọi extra đều bịa.

Chưa phân loại ngữ nghĩa đầy đủ68 FP contribution; không suy ra tất cả phải xóa.

## Method: chủ yếu bỏ kỹ thuật, feature và procedure

Precision **82,28%**, recall chỉ **45,14%**; FN79 so với FP14. Trong output hiện
tại, việc thiếu method đáng ưu tiên hơn lọc thêm các nhãn method.

**Bảy bài để method=[] dù reference có method**, tương ứng15/79 FN:

| Bài | Ý có căn cứ cần rà | Raw attempts |
|---|---|---|
| P000781 | Meta-analysis, moderator analyses | Tất cả rỗng |
| P001431 | Literature synthesis, classification schema | Tất cả rỗng |
| P002273 | Minimal lemma pair counts/comparison | Tất cả rỗng |
| P002586 | Semi-supervised training, speaker adaptation, bottleneck features | Review sinh được2 method đầu nhưng applied bỏ |
| P003187 | Survey, antecedents–behaviours–consequences framework | Tất cả rỗng |
| P003614 | Analysis at informational/intentional levels | Tất cả rỗng; nguồn bị cắt, cần giữ giới hạn nguồn |
| P003809 | Iteration schemes/progressive alignment/T-Coffee | Tất cả rỗng |

Ngoài nhóm rỗng, có bỏ kỹ thuật độc lập: P001963 thiếu LDA/Girvan-Newman,
P003579 thiếu softmax classifier, P003565 thiếu online large-margin learning,
P001409 thiếu dictionary/word-level features, P002877 thiếu multilingual
encoder-decoder architecture và source embeddings cho review classifier.

Không phải cả79 FN là mất nội dung: P001806 đã có meta-learning trong nhãn dài;
P001903 đã chứa convolutions trong nhãn gộp; P004047 có Morfessor algorithm
nhưng không ghép Morfessor. Tách phần coverage thật khỏi granularity/matcher.

## Nguyên nhân đã phân biệt bằng output thật

1. **Review khóa facet dựa trên lỗi lexical, không dựa trên completeness.**
   P002586: raw review có2 method và finding giữ Tamil/điều kiện; applied giữ
   method rỗng và finding cũ. Cả raw lẫn applied đều không có lỗi validator.
   Đã tái hiện trong `tmp/pilot36_review.py`, trường scope_regression_probe
   của error_analysis.json. Đây là lỗi logic có thể khóa bằng regression test.
2. **Candidate pool chưa chứa ý cần lấy.** Sáu trong bảy bài method rỗng vẫn
   rỗng ở mọi raw attempt; tám ca artifact trên cũng thiếu trong mọi raw
   contribution. Mở khóa scope hoặc đổi tiebreak một mình không giải quyết hết.
   Prompt hiện đã yêu cầu inventory/introduced artifacts, nhưng model chưa làm
   đủ; nên đo thay đổi cách thực hiện coverage review thay vì chỉ thêm lời nhắc.
3. **Biểu diễn và đánh giá tạo thêm bất đồng.**22/65 contribution FN còn nội
   dung trong output. Matcher cũng nhận TP thiếu qualifier ở P002586/P001806
   và chặn sai phạm vi phủ định ở P002877. Sửa evaluator cần phép đánh giá riêng;
   giữ mốc hiện tại khi đo thay đổi extraction.

## Phạm vi sửa tiếp đề xuất

**Bước1 — sửa review nhỏ, đo riêng:** cho review bổ sung method/facet rỗng có
evidence, đồng thời giữ những item đúng đã có; cho phép sửa qualifier được
nguồn hỗ trợ thay vì khóa cả facet khi validator không báo lỗi. Không mở lại
mọi facet để viết lại tự do. Regression phải bắt P002586, giữ output rỗng hợp
lệ của P003491, không che schema errors và vẫn replay raw/applied audit được.

**Bước2 — coverage method/contribution:** kiểm inventory từ từng câu nguồn cho
algorithm/model, feature, procedure; đối chiếu riêng artifact được giới thiệu
và findings dương/âm với draft. Bổ sung ý thiếu trước khi rút gọn nhãn, giữ
qualifier. Áp dụng quy tắc chung theo nguồn, không chèn ID/tên/đáp án pilot vào
prompt. Các ca thiếu ở mọi attempt cần generation mới để đánh giá hiệu quả.

**Bước3 — chuẩn hóa đơn vị nhãn và rà matcher/reference riêng:** named artifact
ngắn, một technique độc lập mỗi item; findings giữ đủ subject/metric/condition.
Không ép mọi finding ngắn như method và không hạ threshold để tăng điểm.

Giữ cùng reference/evaluator/ngưỡng0,85 khi đo hai bước đầu, báo cả micro,
macro và từng facet. Kiểm regression cho problem/dataset đã cải thiện; sau khi
dev ổn mới kiểm cohort mới. Không kỳ vọng sửa scope một ca sẽ giải quyết toàn
bộ79 FN method hoặc133 bất đồng contribution.

Lượt này bổ sung phân tích, chưa sửa production hoặc push kernel mới. Không
chạy lại model/embedding vì đây là phân tích output và attempts đã lưu, không
phải đo điểm của một generator mới.

## Bằng chứng

- [Counts,7 ca method rỗng,8 artifact probes](../../../data/exp_a/evaluation/pilot50_v3_6_ai_v1/priority_audit.json).
- [Triage65 contribution FN, kèm nguồn và selected labels](../../../data/exp_a/evaluation/pilot50_v3_6_ai_v1/contribution_fn_triage.jsonl).
- [Báo cáo chấm và đối chiếu version](KAGGLE_PILOT50_V3_6_EVALUATION_2026-10-16.md).
- Tái lập thống kê/probes: `.venv-qwen/Scripts/python.exe -X utf8 -B tmp/pilot36_priority_audit.py`.
