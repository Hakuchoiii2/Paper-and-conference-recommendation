# Rà soát output Kaggle exp_A — 15/10/2026

Đã tải output thực tế của `htnkhi/exp-a-qwen-v3-pilot50`, đối chiếu với code/prompt local và replay toàn bộ 16 lượt sinh còn lưu. Kernel hoàn thành 5/50 bài; 45 bài còn missing. Đây là báo cáo chẩn đoán và đọc đối chiếu nguồn, chưa phải đánh giá ngữ nghĩa bằng reference độc lập.

## Những gì đã đổi so với local

| Thành phần | Local hiện hành | Kaggle pilot |
| --- | --- | --- |
| Prompt / guideline | `docs/ANNOTATION_PROMPT.md` 1.5, guideline 1.0 | Prompt và guideline 3.0 trong `data/exp_a/prompts/` |
| Hướng dẫn | Có một ví dụ phát triển; policy runtime yêu cầu giữ ít nhất 70% từ trong span nguồn | Nhấn mạnh đúng vai trò facet, tài nguyên có tên, tách nhãn, giữ điều kiện/phủ định/số liệu; chưa có ví dụ minh họa |
| Grounding | Kiểm tra retention >=70% với chuẩn hóa biến thể động từ | Cho phép bỏ nhiều từ hơn nhưng giữ thứ tự từ nguồn; kiểm tra thêm phủ định, số liệu và mô tả dataset |
| Sinh | Mặc định sampling với temperature/top_p/top_k | `do_sample=false`; các tham số sampling không chi phối việc sinh |
| Kết thúc | Có score từng lượt và fallback chọn best attempt, giữ audit/lỗi | Chỉ lưu khi extract rồi self-review đều hợp lệ; không có score chọn best attempt |

SHA-256 của code generator, module v3, hai prompt, corpus và config tải từ Kaggle khớp các file local hiện tại. Đây là đúng gói đã chạy, không phải suy đoán từ tên kernel.

## Lỗi validation xác nhận được

`last_failure.json` chứa hai lượt của P004047. Metadata của 5 bài thành công còn giữ 14 lượt. Tổng cộng có 16 raw responses để replay. Cả 16 parse được JSON; các lỗi nhãn tái hiện được đều là:

`concept must use source words in their original order; no invented synonyms`

Khi kiểm tra từng nhãn riêng, 6 lượt không hợp lệ có tổng cộng 20 nhãn lỗi. Code đang dừng ở lỗi đầu tiên và gói nó thành list một phần tử, nên `validation_errors=1` không có nghĩa chỉ có đúng một nhãn lỗi.

| Bài / lượt | Nhãn lỗi phát hiện khi kiểm tra riêng | Số lỗi ghi trong metadata |
| --- | ---: | ---: |
| P001407 / 1 | 3 | 1 |
| P001903 / 1 | 1 | 1 |
| P002840 / 1 | 2 | 1 |
| P003085 / 1 | 2 | 1 |
| P004047 / 1 | 7 | 1 |
| P004047 / 2 | 5 | 1 |

Các nguyên nhân khác nhau đang dùng chung một thông báo:

1. **Đổi từ hoặc đảo thứ tự.** P001903 dùng `long sentences in biomedical texts`, trong khi evidence dùng `long sentences ... biomedical contexts`. P001407 dùng `refine automatic lexical discovery results`, trong khi `results` đứng trước `automatic lexical discovery` trong câu nguồn.
2. **Chọn nhầm evidence.** P001407 chọn A6 cho `apply statistically-based syntactic similarity measure`; cụm similarity measure thực tế nằm ở A2. P004047 gộp `unsupervised morphology learning` với `Morfessor` nhưng chỉ chọn A5, không chứa đủ cả cụm.
3. **Nguồn bị lỗi trích văn bản/OCR.** P004047 chứa `ma chine`, `poorl y`, `mo rphemelike`, `Transl ation`, `morpho logically`. Model viết từ nguyên vẹn nên không còn khớp token nguồn. Đã thử riêng nhãn `morphologically well motivated structures are learned`: bị từ chối trên nguồn gốc; chỉ nối `morpho logically` trong bản sao fixture thì validator chấp nhận. Corpus thật không bị sửa.

Không thể kết luận mọi bài trong 45 bài thất bại đều có cùng lỗi: raw attempts của 44 bài đã bị ghi đè. SQLite chỉ lưu một câu lỗi tổng quát mỗi bài; `last_failure.json` chỉ còn bài cuối.

## Những điểm cần sửa trước lần chạy tiếp

1. **Lưu audit theo từng paper và trả lỗi đủ vị trí.** Thay vì chỉ một `last_failure.json`, giữ raw responses, stage, facet/index, concept, evidence_id, evidence và lỗi cho mỗi bài. Retry nhận hết các lỗi trong một lượt. Hiện phản hồi chung không cho model biết phải sửa nhãn nào; mất audit còn khiến không thể phân tích đầy đủ 45 thất bại.
2. **Khôi phục chọn best attempt nhưng chấm theo quy tắc v3.** Có thể giữ self-review và chọn ứng viên tốt nhất khi hết lượt, lưu rõ fallback và lỗi. Không được đổi tên fallback thành kết quả đã qua validation. Không bê nguyên scorer local vì nó còn dùng ngưỡng retention 70%, vốn khác v3; điểm support cũng không phải độ đúng ngữ nghĩa. Nhãn sai evidence, đổi phủ định hoặc số liệu phải tiếp tục được đánh dấu, không hợp thức hóa bằng điểm tổng.
3. **Sửa luồng review/retry.** Ngân sách ba lượt đang dùng chung cho extract và review. 39 bài dừng sau hai lần extract lỗi; 6 bài có extract hợp lệ nhưng review cuối lỗi; 5 bài được lưu. Review nên nhận được nháp và lỗi cụ thể để sửa, thay vì chỉ chạy khi toàn bộ bản extract đã sạch. Nếu giữ điều kiện hiện tại thì cần ngân sách tách rõ cho sửa extract và review.
4. **Bổ sung ví dụ và chỉ dẫn evidence vào prompt.** Minh họa một nhãn đúng, một nhãn đổi từ/đảo thứ tự sai, và một nhãn đúng nghĩa nhưng chọn nhầm A-id. Yêu cầu chọn câu trước, lấy cụm từ từ chính câu đó, giữ nguyên điều kiện và giới hạn. Tránh chỉ thêm các quy tắc bằng lời rồi kỳ vọng model 4B tự suy ra cách thực hiện.
5. **Đánh dấu chất lượng nguồn và rà ngữ nghĩa.** Cần phân biệt abstract khoa học, văn bản bị vỡ từ và dữ liệu không phải abstract. Giữ raw nguồn; mọi bản làm sạch cần truy vết được, không nối token tùy tiện. Các nhãn qua grounding vẫn cần kiểm tra đúng facet và điều kiện của claim.

## Đọc chất lượng các output đã lưu

| Bài | Nhận xét dựa trên nguồn |
| --- | --- |
| P001407 | Có task/method hợp lý sau retry. Contribution giữ `union ... is promising` nhưng bỏ giới hạn `although only partially successful in the experiments run so far`; cần giữ giới hạn này để không làm mạnh claim. |
| P001903 | Có task, kỹ thuật attention/convolution và tên tài nguyên. Contribution dài gần nguyên câu; không phải lỗi JSON, nhưng có thể tách claim và evidence để nhãn gọn hơn mà vẫn giữ phạm vi. |
| P002840 | Phân biệt được negation/modality và các hiệu ứng. Các contribution vẫn cần rà xem đâu là phương pháp, đâu là phát hiện; grounding không tự xác định vai trò. |
| P003085 | `increasing interest in large-scale classification ...` được gán problem, nhưng câu này là bối cảnh, chưa nêu hạn chế/câu hỏi nghiên cứu. Self-review không sửa được lỗi vai trò này. |
| P003491 | Cả năm facet rỗng. Abstract là nội dung quảng cáo tải sách, có các câu như `Thank you for downloading ...`, không phải abstract nghiên cứu. Trả rỗng hợp lý; cần gắn trạng thái nguồn không đạt. Bản local cũ cũng rỗng. |

Vì vậy 5 bài được lưu gồm 4 bài có nhãn và một nguồn không đạt với toàn nhãn rỗng. Tỷ lệ 5/50 chỉ là mức hoàn thành theo protocol; không phải accuracy ngữ nghĩa.

## Kiểm chứng và giới hạn

- `build_exp_a.check_outputs(remote_root, config, allow_partial=True)` chấp nhận hash/provenance và output partial: 5 completed, 45 failed.
- Replay raw responses qua đúng `extraction_v3.annotate`: tái tạo chính xác 5 kết quả đã lưu và failure audit của P004047; không gọi Qwen/GPU.
- Kiểm tra từng nhãn qua `extraction_v3.ground_response`: 20 lỗi trên 6 lượt lỗi còn lưu.
- Probe OCR chỉ thay một chuỗi trong bản sao bộ nhớ, xác nhận một lỗi có nguyên nhân từ nguồn bị vỡ từ.
- Dữ liệu chi tiết: [kaggle_output_audit.json](../../../data/exp_a/.kaggle/review/kaggle_output_audit.json). Raw output: [thư mục tải về](../../../data/exp_a/.kaggle/downloads/exp_a_run/data/exp_a/generated_v3_pilot50/).
- Chưa sửa generator/prompt, chưa chạy inference lại, chưa tạo điểm semantic trên reference độc lập. Không thể khôi phục raw responses của 44 bài đã mất từ output hiện tại.
